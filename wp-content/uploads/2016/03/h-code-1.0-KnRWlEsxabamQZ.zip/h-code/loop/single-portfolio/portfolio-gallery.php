<?php
/**
 * displaying portfolio single posts in gallery for portfolio
 *
 * @package H-Code
 */
?>
<?php
$portfolio_gallery = hcode_post_meta('hcode_gallery');
$gallery = explode(",",$portfolio_gallery);
$i=1;
$image = '';
if(is_array($gallery)):
	foreach ($gallery as $k => $value) {
		$thumb_gallery = wp_get_attachment_image_src( $value, 'full' );
		if($i == 1):
			$image .= '<a href="'.$thumb_gallery[0].'" title="'.get_the_title().'">';
				$image .= '<img src="'.$thumb_gallery[0].'" width="'.$thumb_gallery[1].'" height="'.$thumb_gallery[2].'" alt="'.get_the_title().'">';
			$image .= '</a>';
		else :
			$image .= '<a href="'.$thumb_gallery[0].'" title="'.get_the_title().'"></a>';
		endif;
		$i++;
	}
else:
	$image .= '<img src="' . HCODE_THEME_ASSETS_URI . '/images/no-image.jpg" width="900" height="600" alt="" />';
endif;
echo '<div class="gallery-img lightbox-gallery margin-bottom-30px">';
	echo $image;
echo '</div>';

$portfolio_image=hcode_post_meta('hcode_featured_image');
if($portfolio_image == 1){
	$thumb = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'full' );
	$url = $thumb['0'];
    if($url):
        echo '<div class="gallery-img margin-bottom-30px">';
            echo '<img src="' . $url . '" width="'.$thumb[1].'" height="'.$thumb[2].'" alt="'.get_the_title().'"/>';
        echo '</div>';
    else:
    	echo '<img src="' . HCODE_THEME_ASSETS_URI . '/images/no-image.jpg" width="900" height="600" alt="" />';
    endif;
}
?>