<?php
/**
 * displaying portfolio single posts featured image for portfolio
 *
 * @package H-Code
 */
?>
<?php
$portfolio_image=hcode_post_meta('hcode_image');
if($portfolio_image == 1){
	$thumb = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'full' );
	$url = $thumb['0'];
    if($url):
        echo '<div class="gallery-img margin-bottom-30px">';
            echo '<img src="' . $url . '" width="'.$thumb[1].'" height="'.$thumb[2].'" alt="'.get_the_title().'" />';
        echo '</div>';
    else:
    	echo '<img src="' . HCODE_THEME_ASSETS_URI . '/images/no-image.jpg" width="900" height="600" alt="" />';
    endif;
}
?>