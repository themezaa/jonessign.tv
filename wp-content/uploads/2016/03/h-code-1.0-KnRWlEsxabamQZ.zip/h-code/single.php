<?php
/**
 * The template for displaying all single posts
 *
 * @package H-Code
 */

get_header(); ?>

<?php
    // Start of the loop.
    while ( have_posts() ) : the_post();
        $layout_settings = $enable_container_fluid = $class_main_section = $section_class = $single_post_layout = '';
        // Get Single Post Laayout From Theme option.
        $layout_settings_inner = hcode_option('hcode_layout_settings');
        // Get Single Post Laayout From Post.
        $single_layout_settings = hcode_option('hcode_single_layout_settings');
        // Get Theme option.
        $hcode_options = get_option( 'hcode_theme_setting' );
        // Set Layout Setting
        if($layout_settings_inner == 'default'){
            $layout_settings = (isset($hcode_options['hcode_layout_settings'])) ? $hcode_options['hcode_layout_settings'] : '';
            $enable_container_fluid = (isset($hcode_options['hcode_enable_container_fluid'])) ? $hcode_options['hcode_enable_container_fluid'] : '';
        }else{
            $layout_settings = $layout_settings_inner;
            $enable_container_fluid = hcode_post_meta('hcode_enable_container_fluid');
        }

        if($single_layout_settings == 'default'){
            $single_post_layout = (isset($hcode_options['hcode_single_layout_settings'])) ? $hcode_options['hcode_single_layout_settings'] : '';
        }else{
            $single_post_layout = $single_layout_settings;
        }

        switch ($layout_settings) {
        	case 'hcode_layout_full_screen':
        		if(isset($enable_container_fluid) && $enable_container_fluid == '1') {
                    $class_main_section .= 'container-fluid';
                    $section_class .= 'no-padding';
                }else{
                    $class_main_section .= 'container';
                    $section_class .= 'no-padding';
                }
            break;

        	case 'hcode_layout_both_sidebar':
                $section_class .= '';
        		$class_main_section .= 'container col3-layout';
        	break;

        	case 'hcode_layout_left_sidebar':
        	case 'hcode_layout_right_sidebar':
                $section_class .= 'no-padding-bottom';
        		$class_main_section .= 'container col2-layout';
        	break;
        	
        	default:
                $section_class .= '';
        		$class_main_section .= 'container';
        	break;
        }
    ?>
    <section <?php echo post_class($section_class); ?>>
        <div class="<?php echo $class_main_section; ?>">
		    <div class="row">
		    <?php
                // If Is Set Get Post Left Sidebar.
                get_template_part('templates/sidebar-left'); 
                            
        		switch ($single_post_layout) {
        			case 'hcode_single_layout_standard':
                        // Standard Post layout.
        				get_template_part('templates/single-post/standard','post');
        			break;

        			case 'hcode_single_layout_full_width':
                        // Full Width Header Image Post layout.
        				get_template_part('templates/single-post/full','post');
        			break;

        			case 'hcode_single_layout_full_width_image_slider':
                        // Full Width With Image Slider Post layout.
        				get_template_part('templates/single-post/full','post-with-slider');
        			break;

        			case 'hcode_single_layout_full_width_lightbox':
                        // Full Width With Lightbox Slider Gallery layout.
        				get_template_part('templates/single-post/full','width-with-lightbox-gallery');
        			break;
        		}
                // If Is Set Get Post Right Sidebar.
		        get_template_part('templates/sidebar-right');

                // If Is Set Get Post Related Posts.
                $related_posts = hcode_option('hcode_enable_related_posts');
                if( $related_posts == 'default' ):
                    $enable_related_posts = (isset($hcode_options['hcode_enable_related_posts'])) ? $hcode_options['hcode_enable_related_posts'] : '';
                else:
                    $enable_related_posts = $related_posts;
                endif;

                if($enable_related_posts == 1):
                    hcode_single_post_related_posts();
                endif;
            ?>
	        </div>
	    </div>
    </section>
	
<?php
// End of the loop.
endwhile;
?>
<?php get_footer(); ?>