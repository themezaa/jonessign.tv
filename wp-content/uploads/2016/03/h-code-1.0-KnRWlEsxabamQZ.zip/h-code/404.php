<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package H-Code
 */

get_header();?>

<?php
$title_text = ( hcode_option('404_title_text') ) ? '<p class="not-found-title black-text">'.hcode_option('404_title_text').'</p>' : '';
$content_text = ( hcode_option('404_content_text') ) ? '<p class="text-med text-uppercase letter-spacing-2">'.hcode_option('404_content_text').'</p>' : '';
$img = hcode_option('404_image');
$image = ( hcode_option('404_image') ) ? '<img src="'.$img['url'].'" alt="" width="'.$img['width'].'" height="'.$img['height'].'"/>' : '';
$button = ( hcode_option('404_button') ) ? hcode_option('404_button') : 'Go to home page';
$button_url = ( hcode_option('404_button_url') ) ? get_permalink(get_page_by_path( hcode_option('404_button_url') )) : home_url();

$top_header_class = '';
$hcode_options = get_option( 'hcode_theme_setting' );
$hcode_enable_header = (isset($hcode_options['404_enable_header'])) ? $hcode_options['404_enable_header'] : '';
$hcode_header_layout = (isset($hcode_options['404_header_type'])) ? $hcode_options['404_header_type'] : '';
   
if($hcode_enable_header == 1 && $hcode_header_layout != 'headertype8')
{
    $top_header_class .= 'content-top-margin';
}
?>
<?php // Start 404 Page Content ?>
<section class="<?php echo $top_header_class; ?> no-padding-bottom border-top wow fadeIn">
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-sm-8 col-xs-11 text-center center-col">
                <?php echo $title_text; ?>
                <?php echo $content_text; ?>
                <a class="highlight-button-dark btn btn-small no-margin-right" href="<?php echo $button_url;?>"><?php echo $button; ?></a>
            </div>
        </div>
        <?php if($image): ?>
            <div class="row">
                <div class="col-md-10 col-sm-8 col-xs-11 center-col">
                    <?php echo $image;?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php // End 404 Page Content ?>
<?php get_footer(); ?>