<?php
/**
 * H-Code Theme Extra Function.
 *
 * @package H-Code
 */
?>
<?php
if ( ! function_exists( 'hcode_set_header' ) ) {
    function hcode_set_header( $id ){
        if(get_post_type( $id ) == 'portfolio' && is_singular('portfolio')){
            $enable_ajax = get_post_meta($id,'hcode_enable_ajax_popup_single',true);
        }else{
            $enable_ajax = '';
        }
        
        if($enable_ajax == 'yes'){
            remove_all_actions('wp_head');
        }
    }
}

if ( ! function_exists( 'hcode_set_footer' ) ) {
    function hcode_set_footer( $id ){
        if(get_post_type( $id ) == 'portfolio' && is_singular('portfolio')){
            $enable_ajax = get_post_meta($id,'hcode_enable_ajax_popup_single',true);
        }else{
            $enable_ajax = '';
        }

        if($enable_ajax == 'yes'){
            remove_all_actions('wp_footer');
            add_action('wp_footer','hcode_hook_for_ajax_page');
        }
    }
}

if ( ! function_exists( 'hcode_post_meta' ) ) {
    function hcode_post_meta( $option ){
    	global $post;
    	$value = get_post_meta( $post->ID, $option.'_single', true);
    	return $value;
    }
}

if ( ! function_exists( 'hcode_option' ) ) {
    function hcode_option( $option ){
    	global $hcode_theme_settings, $post;
    	$hcode_single = false;
    	if(is_singular()){
    		$value = get_post_meta( $post->ID, $option.'_single', true);
    		$hcode_single = true;
    	}

    	if($hcode_single == true){
    		if (is_string($value) && (strlen($value) > 0 || is_array($value))) {
    			return $value;
    		}
    	}
    	if(isset($hcode_theme_settings[$option]) && $hcode_theme_settings[$option] != ''){
    		$option_value = $hcode_theme_settings[$option];
    		return $option_value;
    	}
    	return false;
    }
}

if ( ! function_exists( 'hcode_option_url' ) ) {
    function hcode_option_url($option) {
    	$image = hcode_option($option);
    	if (is_array($image) && isset($image['url']) && !empty($image['url'])) {
    		return $image['url'];
    	}
    	return false;
    }
}

if( ! function_exists( 'hcode_script_add_data' ) ) :

function hcode_script_add_data( $handle, $key, $value ) {
    global $wp_scripts;
    return $wp_scripts->add_data( $handle, $key, $value );
}

endif; // ! function_exists( 'hcode_script_add_data' )

if ( version_compare( $GLOBALS['wp_version'], '4.2', '<' ) ) {
    add_filter( 'script_loader_tag', function( $tag, $handle ) {
        global $wp_scripts;
        if( isset( $wp_scripts->registered[$handle]->extra['conditional'] ) && $wp_scripts->registered[$handle]->extra['conditional'] ) {
            $tag = "<!--[if {$wp_scripts->registered[$handle]->extra['conditional']}]>\n" . $tag . "<![endif]-->\n";
        }
        return $tag;
    }, 10, 2 );
}

add_action( 'wp_before_admin_bar_render', 'hcode_remove_customizer_adminbar' ); 

if ( ! function_exists( 'hcode_remove_customizer_adminbar' ) ) {
    function hcode_remove_customizer_adminbar()
    {
        global $wp_admin_bar;
        $wp_admin_bar->remove_menu('customize');
    }
}

/**
 * Force All Page To Under Construction If "enable-under-construction" is enable
 */
if ( ! function_exists( 'hcode_get_address' ) ) {
    function hcode_get_address() {
        // return the full address
        return hcode_get_protocol().'://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
    } // end function hcode_get_address
}

if ( ! function_exists( 'hcode_get_protocol' ) ) {
    function hcode_get_protocol() {
        // Set the base protocol to http
        $protocol = 'http';
        // check for https
        if ( isset( $_SERVER["HTTPS"] ) && strtolower( $_SERVER["HTTPS"] ) == "on" ) {
            $protocol .= "s";
        }
        
        return $protocol;
    } // end function hcode_get_protocol
}
        
add_action('init', 'hcode_force_under_construction', 1);
if ( ! function_exists( 'hcode_force_under_construction' ) ) {
    function hcode_force_under_construction() {
        // this is what the user asked for (strip out home portion, case insensitive)
        $userrequest = str_ireplace(home_url(),'',hcode_get_address());
        $userrequest = rtrim($userrequest,'/');

        if (hcode_option('enable_under_construction') == 1 && !current_user_can('level_10') && hcode_option('under_construction_page') != '' ) { 
            
            $do_redirect = '';
            $do_redirect = '/'.hcode_option('under_construction_page');

            if ( strpos($userrequest, '/wp-login') !== 0 && strpos($userrequest, '/wp-admin') !== 0 ) {
                // Make sure it gets all the proper decoding and rtrim action
                $userrequest = str_replace('*','(.*)',$userrequest);
                $pattern = '/^' . str_replace( '/', '\/', rtrim( $userrequest, '/' ) ) . '/';
                $do_redirect = str_replace('*','$1',$do_redirect);
                $output = preg_replace($pattern, $do_redirect, $userrequest);
                if ($output !== $userrequest) {
                    // pattern matched, perform redirect
                    $do_redirect = $output;
                }
            }else{
                // simple comparison redirect
                $do_redirect = $userrequest;
            }

            if ($do_redirect !== '' && trim($do_redirect,'/') !== trim($userrequest,'/')) {
                // check if destination needs the domain prepended

                if (strpos($do_redirect,'/') === 0){
                    $do_redirect = home_url().$do_redirect;
                }

                header ('HTTP/1.1 301 Moved Permanently');
                header ('Location: ' . $do_redirect);
                exit();
            }
        }
    } // end funcion redirect
}

/**
 * To Add Under Construction Notice To Adminbar For All Logged User
 */
if ( ! function_exists( 'hcode_admin_bar_under_construction_notice' ) ) {
    function hcode_admin_bar_under_construction_notice() {
        global $wp_admin_bar;
    	
    	if (hcode_option('enable_under_construction') == 1) {
    		$wp_admin_bar->add_menu( array(
    			'id' => 'admin-bar-under-construction-notice',
    			'parent' => 'top-secondary',
    			'href' => home_url().'/wp-admin/themes.php?page=hcode_theme_settings',
    			'title' => '<span style="color: #FF0000;">Under Construction</span>'
    		) );
    	}
    }
}
add_action( 'admin_bar_menu', 'hcode_admin_bar_under_construction_notice' );

if ( ! function_exists( 'hcode_slider_pagination' ) ) {
    function hcode_slider_pagination( $pagination , $slider_id = ''){
    	$output  = '';

    	ob_start();

    	if($pagination){
    		$pagination_count = substr_count($pagination, '[hcode_slide_content ');
    		for ($count=0; $count <= $pagination_count-1; $count++){
    			echo '<li data-target="#'.$slider_id.'" data-slide-to="'.$count.'"></li>';
    		}
    	}

    	$result = ob_get_contents();
    	ob_end_clean();
    	$output .= $result;

        return $output;
    }
}
/* For content bootstrap slider pagination */
if ( ! function_exists( 'hcode_bootstrap_content_slider_pagination' ) ) {
    function hcode_bootstrap_content_slider_pagination( $pagination , $slider_id = ''){
        $output  = '';

        ob_start();

        if($pagination){
            $pagination_count = substr_count($pagination, '[hcode_special_slide_content ');
            for ($count=0; $count <= $pagination_count-1; $count++){
                echo '<li data-target="#'.$slider_id.'" data-slide-to="'.$count.'"></li>';
            }
        }

        $result = ob_get_contents();
        ob_end_clean();
        $output .= $result;

        return $output;
    }
}

if ( ! function_exists( 'hcode_owl_pagination_color_classes' ) ) {
    function hcode_owl_pagination_color_classes( $pagination ){
    	$class_list = '';

    	switch($pagination)
    	{
    		case 0:
    			$class_list .= ' dark-pagination';
    			break;

    		case 1:
    			$class_list .= ' light-pagination';
    			break;

    		default:
    			$class_list .= ' dark-pagination';
    			break;
    	}
        return $class_list;
    }
}

if ( ! function_exists( 'hcode_owl_pagination_slider_classes' ) ) {
    function hcode_owl_pagination_slider_classes( $pagination_color ){
    	$class_list = '';

    	switch($pagination_color)
    	{
    		case 0:
    			$class_list .= ' dot-pagination';
    			break;

    		case 1:
    			$class_list .= ' square-pagination';
    			break;

                    case 2:
                        $class_list .= ' round-pagination';
                        break;

    		default:
    			$class_list .= ' dot-pagination';
    			break;
    	}

        return $class_list;
    }
}

if ( ! function_exists( 'hcode_owl_navigation_slider_classes' ) ) {
    function hcode_owl_navigation_slider_classes ($navigation){
    	$class_list = '';

    	switch($navigation)
    	{
    		case 0:
    			$class_list .= ' dark-navigation';
    			break;

    		case 1:
    			$class_list .= ' light-navigation';
    			break;

    		default:
    			$class_list .= ' dark-navigation';
    			break;
    	}

        return $class_list;
    }
}

/* page title option for individual pages*/
if ( ! function_exists( 'hcode_get_title_part' ) ) {
    function hcode_get_title_part(){

    	$top_header_class = '';
    	if( class_exists( 'WooCommerce' ) && (is_product() || is_product_category() || is_product_tag()) || is_404()){
            $enable_header = 2;
        }else{
            $enable_header = hcode_option('hcode_enable_header');
        }

        if($enable_header == '1' || $enable_header == '2'){
        	switch ($enable_header) {
                case '1':
                	$hcode_enable_header = $enable_header;
                    $hcode_header_layout = hcode_option('hcode_header_layout');
                break;

                case '2':
                	$hcode_options = get_option( 'hcode_theme_setting' );
                	$hcode_enable_header = (isset($hcode_options['hcode_enable_header'])) ? $hcode_options['hcode_enable_header'] : '';
                    $hcode_header_layout = (isset($hcode_options['hcode_header_layout'])) ? $hcode_options['hcode_header_layout'] : '';
                break;
            }
            if($hcode_enable_header == 1 && $hcode_header_layout != 'headertype8')
            {
            	$top_header_class .= 'content-top-margin';
            }
        }

    	$enable_title = hcode_option('hcode_enable_title_wrapper');
    	if($enable_title == 0 || is_404())
            return;
    	
    	$page_title = get_the_title();
    	switch ($enable_title) {
            case '2':
                    $hcode_page_title_premade_style = hcode_post_meta('hcode_page_title_premade_style');
    				$page_title_image = hcode_post_meta('hcode_title_background');
    				$hcode_title_parallax_effect = hcode_post_meta('hcode_title_parallax_effect');
    				$page_subtitle = hcode_post_meta('hcode_header_subtitle');
    				$page_title_show_breadcrumb = hcode_post_meta('hcode_page_title_show_breadcrumb');
    				$page_title_show_separater = hcode_post_meta('hcode_page_title_show_separator');
                    
                break;
            case '1':
                    $hcode_options = get_option( 'hcode_theme_setting' );
                    $hcode_enable_title = (isset($hcode_options['hcode_enable_title_wrapper'])) ? $hcode_options['hcode_enable_title_wrapper'] : '';
                    if($hcode_enable_title == 0)
                        return;
                    
                    $hcode_page_title_premade_style = (isset($hcode_options['hcode_page_title_premade_style'])) ? $hcode_options['hcode_page_title_premade_style'] : '';
                    $page_title_image = (isset($hcode_options['hcode_title_background']['url'])) ? $hcode_options['hcode_title_background']['url'] : '';
                    $hcode_title_parallax_effect = (isset($hcode_options['hcode_title_parallax_effect'])) ? $hcode_options['hcode_title_parallax_effect'] : '';
                    $page_subtitle = (isset($hcode_options['hcode_header_subtitle'])) ? $hcode_options['hcode_header_subtitle'] : '';
                    $page_title_show_breadcrumb = (isset($hcode_options['hcode_page_title_show_breadcrumb'])) ? $hcode_options['hcode_page_title_show_breadcrumb'] : '';
                    $page_title_show_separater = (isset($hcode_options['hcode_page_title_show_separator'])) ? $hcode_options['hcode_page_title_show_separator'] : '';
                break;
        }
    	$output = '';    
        if (class_exists('breadcrumb_navigation_xt')) 
        {
            $hcode_breadcrumb = new breadcrumb_navigation_xt;
            $hcode_breadcrumb->opt['static_frontpage'] = false;
            $hcode_breadcrumb->opt['url_blog'] = '';
            $hcode_breadcrumb->opt['title_blog'] = 'Home';
            $hcode_breadcrumb->opt['title_home'] = 'Home';
            $hcode_breadcrumb->opt['separator'] = '';
            $hcode_breadcrumb->opt['tag_page_prefix'] = '';
            $hcode_breadcrumb->opt['singleblogpost_category_display'] = false;
        } 
        	
    	switch ($hcode_page_title_premade_style) {
    		case 'title-white':

                $output .= '<section class="'.$top_header_class.' page-title border-bottom-light border-top-light bg-white">';
                    $output .= '<div class="container">';
                        $output .= '<div class="row">';
                            if($page_title != '' || $page_subtitle != ''){
                                $output .= '<div class="col-lg-8 col-md-7 col-sm-12 slideInUp wow fadeInUp" data-wow-duration="300ms">';
                                    if($page_title){
                                        $output .= '<h1 class="black-text">'.$page_title.'</h1>';
                                    }
                                    if($page_subtitle){
                                        $output .= '<span class="xs-display-none">'.$page_subtitle.'</span>';
                                    }
                                    if($page_title_show_separater == 1){
                                        $output .= '<div class="separator-line margin-three bg-black no-margin-lr sm-margin-top-three sm-margin-bottom-three no-margin-bottom xs-display-none"></div>';
                                    }
                                $output .= '</div>';
                            }
                            if($page_title_show_breadcrumb == 1 && !is_front_page() && get_post_type( get_the_ID() ) != 'product'){
                                $output .= '<div class="col-lg-4 col-md-5 col-sm-12 breadcrumb text-uppercase sm-no-margin-top wow fadeInUp xs-display-none" data-wow-duration="600ms">';
                                    $output .= '<ul class="breadcrumb-gray-text">';
                                        $output .= $hcode_breadcrumb->display();
                                    $output .= '</ul>';
                                $output .= '</div>';
                            }
                        $output .= '</div>';
                    $output .= '</div>';
                $output .= '</section>';
                break;

            case 'title-gray':
                
                $output .= '<section class="'.$top_header_class.' page-title bg-gray">';
                    $output .= '<div class="container">';
                        $output .= '<div class="row">';
                            if($page_title != '' || $page_subtitle != ''){
                                $output .= '<div class="col-lg-8 col-md-7 col-sm-12 slideInUp wow fadeInUp" data-wow-duration="300ms">';
                                    if($page_title){
                                        $output .= '<h1 class="black-text">'.$page_title.'</h1>';
                                    }
                                    if($page_subtitle){
                                        $output .= '<span class="xs-display-none">'.$page_subtitle.'</span>';
                                    }
                                    if($page_title_show_separater == 1){
                                        $output .= '<div class="separator-line margin-three bg-black no-margin-lr sm-margin-top-three sm-margin-bottom-three no-margin-bottom xs-display-none"></div>';
                                    }
                                $output .= '</div>';
                            }
                            if($page_title_show_breadcrumb == 1){
                                $output .= '<div class="col-lg-4 col-md-5 col-sm-12 breadcrumb text-uppercase sm-no-margin-top wow fadeInUp xs-display-none" data-wow-duration="600ms">';
                                    $output .= '<ul class="breadcrumb-gray-text">';
                                        $output .= $hcode_breadcrumb->display();
                                    $output .= '</ul>';
                                $output .= '</div>';
                            }
                        $output .= '</div>';
                    $output .= '</div>';
                $output .= '</section>';
                break;

            case 'title-dark-gray':
                
                $output .= '<section class="'.$top_header_class.' page-title bg-dark-gray">';
                    $output .= '<div class="container">';
                        $output .= '<div class="row">';
                            if($page_title != '' || $page_subtitle != ''){
                                $output .= '<div class="col-lg-8 col-md-7 col-sm-12 slideInUp wow fadeInUp" data-wow-duration="300ms">';
                                    if($page_title){
                                        $output .= '<h1 class="white-text">'.$page_title.'</h1>';
                                    }
                                    if($page_subtitle){
                                        $output .= '<span class="white-text xs-display-none">'.$page_subtitle.'</span>';
                                    }
                                    if($page_title_show_separater == 1){
                                        $output .= '<div class="separator-line margin-three bg-white no-margin-lr sm-margin-top-three sm-margin-bottom-three no-margin-bottom xs-display-none"></div>';
                                    }
                                $output .= '</div>';
                            }
                            if($page_title_show_breadcrumb == 1){
                                $output .= '<div class="col-lg-4 col-md-5 col-sm-12 breadcrumb text-uppercase sm-no-margin-top wow fadeInUp xs-display-none" data-wow-duration="600ms">';
                                    $output .= '<ul class="breadcrumb-white-text">';
                                        $output .= $hcode_breadcrumb->display();
                                    $output .= '</ul>';
                                $output .= '</div>';
                            }
                        $output .= '</div>';
                    $output .= '</div>';
                $output .= '</section>';
                break;

            case 'title-black':

                $output .= '<section class="'.$top_header_class.' page-title bg-black">';
                    $output .= '<div class="container">';
                        $output .= '<div class="row">';
                            if($page_title != '' || $page_subtitle != ''){
                                $output .= '<div class="col-lg-8 col-md-7 col-sm-12 slideInUp wow fadeInUp" data-wow-duration="300ms">';
                                    if($page_title){
                                        $output .= '<h1 class="white-text">'.$page_title.'</h1>';
                                    }
                                    if($page_subtitle){
                                        $output .= '<span class="white-text xs-display-none">'.$page_subtitle.'</span>';
                                    }
                                    if($page_title_show_separater == 1){
                                        $output .= '<div class="separator-line margin-three bg-white no-margin-lr sm-margin-top-three sm-margin-bottom-three no-margin-bottom xs-display-none"></div>';
                                    }
                                $output .= '</div>';
                            }
                            if($page_title_show_breadcrumb == 1){
                                $output .= '<div class="col-lg-4 col-md-5 col-sm-12 breadcrumb text-uppercase sm-no-margin-top wow fadeInUp xs-display-none" data-wow-duration="600ms">';
                                    $output .= '<ul class="breadcrumb-white-text">';
                                        $output .= $hcode_breadcrumb->display();
                                    $output .= '</ul>';
                                $output .= '</div>';
                            }
                        $output .= '</div>';
                    $output .= '</div>';
                $output .= '</section>';

                break;
            case 'title-with-image':
                
                $image_url = $page_title_image ;
                
                $output .= '<section class="'.$top_header_class.' page-title '.$hcode_title_parallax_effect.' parallax-fix">';
                if($image_url){
                    $output .= '<img class="parallax-background-img" src="'.$image_url.'" alt="'.$page_title.'" />';
                }
                    $output .= '<div class="opacity-medium bg-black"></div>';
                    $output .= '<div class="container">';
                        $output .= '<div class="row">';
                            if($page_title != '' || $page_subtitle != ''){
                                $output .= '<div class="col-lg-8 col-md-7 col-sm-12 slideInUp wow fadeInUp" data-wow-duration="300ms">';
                                    if($page_title){
                                        $output .= '<h1 class="white-text">'.$page_title.'</h1>';
                                    }
                                    if($page_subtitle){
                                        $output .= '<span class="white-text xs-display-none">'.$page_subtitle.'</span>';
                                    }
                                    if($page_title_show_separater == 1){
                                        $output .= '<div class="separator-line margin-three bg-white no-margin-lr sm-margin-top-three sm-margin-bottom-three no-margin-bottom xs-display-none"></div>';
                                    }
                                $output .= '</div>';
                            }
                            if($page_title_show_breadcrumb == 1){
                                $output .= '<div class="col-lg-4 col-md-5 col-sm-12 breadcrumb text-uppercase sm-no-margin-top wow fadeInUp xs-display-none" data-wow-duration="600ms">';
                                    $output .= '<ul class="breadcrumb-white-text">';
                                        $output .= $hcode_breadcrumb->display();
                                    $output .= '</ul>';
                                $output .= '</div>';
                            }
                        $output .= '</div>';
                    $output .= '</div>';
                $output .= '</section>';

                break;
            case 'title-large':

                $image_url = $page_title_image ;
                $output .= '<section class="page-title '.$hcode_title_parallax_effect.' parallax-fix page-title-large">';
                if($image_url){
                    $output .= '<img class="parallax-background-img" src="'.$image_url.'" alt="'.$page_title.'" />';
                }
                    $output .= '<div class="opacity-medium bg-black"></div>';
                    $output .= '<div class="container">';
                        $output .= '<div class="row">';
                        	$output .= '<div class="col-md-12 col-sm-12 text-center animated fadeInUp">';
    				            if($page_title != '' || $page_subtitle != ''){
    				                if($page_title_show_separater == 1){
    				                    $output .= '<div class="separator-line bg-yellow no-margin-top margin-four"></div>';
    				                }
    				                if($page_title){
    				                    $output .= '<h1 class="white-text">'.$page_title.'</h1>';
    				                }
    				                if($page_subtitle){
    				                    $output .= '<span class="white-text">'.$page_subtitle.'</span>';
    				                }
    				            }
    				        $output .= '</div>';
    					$output .= '</div>';
                    $output .= '</div>';
                $output .= '</section>';
                break;
            case 'title-large-without-overlay':

                $image_url = $page_title_image ;
                $output .= '<section class="page-title '.$hcode_title_parallax_effect.' parallax-fix page-title-large">';
                if($image_url){
                    $output .= '<img class="parallax-background-img" src="'.$image_url.'" alt="'.$page_title.'" />';
                }
                    $output .= '<div class="container">';
                        $output .= '<div class="row">';
                            $output .= '<div class="col-md-12 col-sm-12 text-center animated fadeInUp">';
                                if($page_title != '' || $page_subtitle != ''){
                                    if($page_title_show_separater == 1){
                                        $output .= '<div class="separator-line bg-yellow no-margin-top margin-four"></div>';
                                    }
                                    if($page_title){
                                        $output .= '<h1 class="black-text">'.$page_title.'</h1>';
                                    }
                                    if($page_subtitle){
                                        $output .= '<span class="text-uppercase gray-text">'.$page_subtitle.'</span>';
                                    }
                                }
                            $output .= '</div>';
                        $output .= '</div>';
                    $output .= '</div>';
                $output .= '</section>';
                break;
            case 'title-small-white':

                $output .= '<section class="'.$top_header_class.' page-title page-title-small border-bottom-light border-top-light bg-white">';
                    $output .= '<div class="container">';
                        $output .= '<div class="row">';
                            if($page_title != ''){
                                $output .= '<div class="col-lg-8 col-md-7 col-md-12 col-sm-12 animated fadeInUp">';
                                    
                                    if($page_title){
                                        $output .= '<h1 class="black-text">'.$page_title.'</h1>';
                                    }
                                    if($page_title_show_separater == 1){
                                        $output .= '<div class="separator-line margin-three bg-black no-margin-lr sm-margin-top-three sm-margin-bottom-three no-margin-bottom xs-display-none"></div>';
                                    }
                                $output .= '</div>';
                            }
                            if($page_title_show_breadcrumb == 1){
                                $output .= '<div class="col-lg-4 col-md-5 col-sm-12 breadcrumb text-uppercase wow fadeInUp xs-display-none" data-wow-duration="600ms">';
                                    $output .= '<ul class="breadcrumb-gray-text">';
                                        $output .= $hcode_breadcrumb->display();
                                    $output .= '</ul>';
                                $output .= '</div>';
                            }
                        $output .= '</div>';
                    $output .= '</div>';
                $output .= '</section>';
                break;
            case 'title-small-gray':

                $output .= '<section class="'.$top_header_class.' page-title page-title-small bg-gray">';
                    $output .= '<div class="container">';
                        $output .= '<div class="row">';
                            if($page_title != ''){
                                $output .= '<div class="col-lg-8 col-md-7 col-md-12 col-sm-12 animated fadeInUp">';
                                    
                                    if($page_title){
                                        $output .= '<h1 class="black-text">'.$page_title.'</h1>';
                                    }
                                    if($page_title_show_separater == 1){
                                        $output .= '<div class="separator-line margin-three bg-black no-margin-lr sm-margin-top-three sm-margin-bottom-three no-margin-bottom xs-display-none"></div>';
                                    }
                                $output .= '</div>';
                            }
                            if($page_title_show_breadcrumb == 1){
                                $output .= '<div class="col-lg-4 col-md-5 col-sm-12 breadcrumb text-uppercase wow fadeInUp xs-display-none" data-wow-duration="600ms">';
                                    $output .= '<ul class="breadcrumb-gray-text">';
                                        $output .= $hcode_breadcrumb->display();
                                    $output .= '</ul>';
                                $output .= '</div>';
                            }
                        $output .= '</div>';
                    $output .= '</div>';
                $output .= '</section>';

                break;
            case 'title-small-dark-gray':

                $output .= '<section class="'.$top_header_class.' page-title page-title-small bg-dark-gray border-bottom-light border-top-light">';
                    $output .= '<div class="container">';
                        $output .= '<div class="row">';
                            if($page_title != ''){
                                $output .= '<div class="col-lg-8 col-md-7 col-md-12 col-sm-12 animated fadeInUp">';
                                    
                                    if($page_title){
                                        $output .= '<h1 class="white-text">'.$page_title.'</h1>';
                                    }
                                    if($page_title_show_separater == 1){
                                        $output .= '<div class="separator-line margin-three bg-white no-margin-lr sm-margin-top-three sm-margin-bottom-three no-margin-bottom xs-display-none"></div>';
                                    }
                                $output .= '</div>';
                            }
                            if($page_title_show_breadcrumb == 1){
                                $output .= '<div class="col-lg-4 col-md-5 col-sm-12 breadcrumb text-uppercase wow fadeInUp xs-display-none" data-wow-duration="600ms">';
                                    $output .= '<ul class="breadcrumb-white-text">';
                                        $output .= $hcode_breadcrumb->display();
                                    $output .= '</ul>';
                                $output .= '</div>';
                            }
                        $output .= '</div>';
                    $output .= '</div>';
                $output .= '</section>';

                break;
            case 'title-small-black':

                $output .= '<section class="'.$top_header_class.' page-title page-title-small bg-black border-bottom-light border-top-light">';
                    $output .= '<div class="container">';
                        $output .= '<div class="row">';
                            if($page_title != ''){
                                $output .= '<div class="col-lg-8 col-md-7 col-md-12 col-sm-12 animated fadeInUp">';
                                    
                                    if($page_title){
                                        $output .= '<h1 class="white-text">'.$page_title.'</h1>';
                                    }
                                    if($page_title_show_separater == 1){
                                        $output .= '<div class="separator-line margin-three bg-white no-margin-lr sm-margin-top-three sm-margin-bottom-three no-margin-bottom xs-display-none"></div>';
                                    }
                                $output .= '</div>';
                            }
                            if($page_title_show_breadcrumb == 1){
                                $output .= '<div class="col-lg-4 col-md-5 col-sm-12 breadcrumb text-uppercase wow fadeInUp xs-display-none" data-wow-duration="600ms">';
                                    $output .= '<ul class="breadcrumb-white-text">';
                                        $output .= $hcode_breadcrumb->display();
                                    $output .= '</ul>';
                                $output .= '</div>';
                            }
                        $output .= '</div>';
                    $output .= '</div>';
                $output .= '</section>';

                break;
            case 'title-center-align':

                $output .= '<section class="'.$top_header_class.' page-title bg-black border-bottom-light border-top-light">';
                    $output .= '<div class="container">';
                        $output .= '<div class="row">';
                            if($page_title != '' || $page_subtitle != ''){
                                $output .= '<div class="col-md-12 col-sm-12 animated text-center fadeInUp">';
                                    
                                    if($page_title){
                                        $output .= '<h1 class="white-text">'.$page_title.'</h1>';
                                    }
                                    if($page_subtitle){
                                        $output .= '<span class="white-text xs-display-none">'.$page_subtitle.'</span>';
                                    }
                                    if($page_title_show_separater == 1){
                                        $output .= '<div class="separator-line margin-three bg-white sm-margin-top-three sm-margin-bottom-three no-margin-bottom xs-display-none"></div>';
                                    }
                                $output .= '</div>';
                            }
                        $output .= '</div>';
                    $output .= '</div>';
                $output .= '</section>';
                break;
    	}
    	echo $output;
    }
}


if ( ! function_exists( 'hcode_categories_postcount_filter' ) ) {
    function hcode_categories_postcount_filter ($variable) {
       $variable = str_replace('(', '<span class="light-gray-text">/ ', $variable);
       $variable = str_replace(')', '</span>', $variable);
       return $variable;
    }
}
add_filter('wp_list_categories','hcode_categories_postcount_filter');

add_filter('wp_list_categories', 'hcode_add_new_class_list_categories');
if ( ! function_exists( 'hcode_add_new_class_list_categories' ) ) {
    function hcode_add_new_class_list_categories($list) {
        $list = str_replace('cat-item ', 'cat-item widget-category-list light-gray-text ', $list); 
        return $list;
    }
}

add_filter('get_archives_link', 'hcode_archive_count_no_brackets');
if ( ! function_exists( 'hcode_archive_count_no_brackets' ) ) {
    function hcode_archive_count_no_brackets($links) {
    	$links = str_replace('(', '<span class="light-gray-text">/ ', $links);
    	$links = str_replace(')', '</span>', $links);
    	return $links;
    }
}
add_filter('get_archives_link', 'hcode_add_new_class_list_archives');
if ( ! function_exists( 'hcode_add_new_class_list_archives' ) ) {
    function hcode_add_new_class_list_archives($list) {
        $list = str_replace('<li>', '<li class="widget-category-list"> ', $list); 
        return $list;
    }
}

if ( ! function_exists( 'hcode_kana_wp_tag_cloud_filter' ) ) {
    function hcode_kana_wp_tag_cloud_filter($return, $args)
    {
      return '<div class="tags_cloud tags">'.$return.'</div>';
    }
}
add_filter('wp_tag_cloud','hcode_kana_wp_tag_cloud_filter', 10, 2);
/*  comment form customization   */

if ( ! function_exists( 'hcode_theme_comment' ) ) {
    function hcode_theme_comment($comment, $args, $depth) {
        
    	$GLOBALS['comment'] = $comment;
    	extract($args, EXTR_SKIP);

    	if ( 'div' == $args['style'] ) {
    		$tag = 'div';
    		$add_below = 'comment';
    	} else {
    		$tag = 'li';
    		$add_below = 'div-comment';
    	}
            
    ?>
    	<<?php echo $tag ?> <?php comment_class( empty( $args['has_children'] ) ? 'blog-comment' : 'blog-comment parent' ) ?> id="comment-<?php comment_ID() ?>">
    	<?php if ( 'div' != $args['style'] ) : ?>
    	<div id="div-comment-<?php comment_ID() ?>" class="comment-body">
    	<?php endif; ?>
            
    	<div class="comment-author vcard comment-avtar">
    	<?php //echo '<pre>'; print_r($comment);?>
    	<!-- <img height="100" width="100" class="avatar avatar-96 photo avatar-default" src="<?php echo get_the_author_meta('author_profile_picture', $comment->user_id);?>" alt=""> -->
    	<?php if ( $args['avatar_size'] != 0 ) echo get_avatar( $comment, $args['avatar_size'] );	?>
    	</div>
    	<?php if ( $comment->comment_approved == '0' ) : ?>
    		<em class="comment-awaiting-moderation"><?php esc_html_e( 'Your comment is awaiting moderation.', 'H-Code' ); ?></em>
    		<br />
    	<?php endif; ?>
    	<div class="comment-right comment-text overflow-hidden position-relative">
                <div class="blog-date no-padding-top">
                    <div class="comment-meta commentmetadata">  
                            <a href="<?php echo htmlspecialchars( get_comment_link( $comment->comment_ID ) ); ?>">
                            <?php printf( esc_html__( '%s, ', 'H-code' ), get_comment_author_link() ); ?>
                            </a>
                            
                            <?php
                            /* translators: 1: date, 2: time */
                            printf( esc_html__('%1$s','H-Code'), get_comment_date(),  get_comment_time() ); 
                            ?>
                            
                            <?php comment_reply_link( array_merge( $args, array( 'add_below' => $add_below, 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
                    </div>
                </div>
                <?php comment_text(); ?>
    	</div>
    	<?php if ( 'div' != $args['style'] ) : ?>
    	</div>
    	<?php endif; ?>
    <?php
    }
}

// filter to replace class on reply link
add_filter('comment_reply_link', 'hcode_replace_reply_link_class');
if ( ! function_exists( 'hcode_replace_reply_link_class' ) ) {
    function hcode_replace_reply_link_class($class){
        $class = str_replace("class='comment-reply-link", "class='comment-reply-link comment-reply inner-link bg-black", $class);
        return $class;
    }
}

add_filter('the_category', 'hcode_the_category');
if ( ! function_exists( 'hcode_the_category' ) ) {
    function hcode_the_category($cat_list)
    {
        return str_ireplace('<a', '<a class="white-text"', $cat_list);
    }
}

/* Remove Visual Composer Default style */
add_action( 'wp_enqueue_scripts', 'hcode_dequeue_vc_style', 9999 );
add_action( 'wp_head', 'hcode_dequeue_vc_style', 9999 );
if ( ! function_exists( 'hcode_dequeue_vc_style' ) ) {
    function hcode_dequeue_vc_style(){
        wp_dequeue_style('js_composer_front');
        wp_deregister_style('js_composer_front');
    }
}

/* Post Navigation */
if ( ! function_exists( 'hcode_single_post_navigation' ) ) :
    function hcode_single_post_navigation() {
        // Don't print empty markup if there's nowhere to navigate.
        
        $previous = ( is_attachment() ) ? get_post( get_post()->post_parent ) : get_adjacent_post( false, '', true );
        $next     = get_adjacent_post( false, '', false );

        if ( ! $next && ! $previous ) {
            return;
        }
        if ( is_attachment() && 'attachment' == $previous->post_type ) {
            return;
        }
        $link = $cat_name = $next_image = $prev_image = '';
        
        $assign_post_category = get_the_category();
        $link = get_category_link($assign_post_category[0]->cat_ID);
        $cat_name = $assign_post_category[0]->cat_name;
       
        if ( $previous &&  has_post_thumbnail( $previous->ID ) ) {
            $prevthumb = wp_get_attachment_image_src( get_post_thumbnail_id( $previous->ID ), 'hcode-navigation-img' );
            if($prevthumb[0]):
                $prev_image = $prevthumb[0];
            else:
                $prev_image = HCODE_THEME_ASSETS_URI . '/images/no-image-133x83.jpg';
            endif;
        }else{
            $prev_image = HCODE_THEME_ASSETS_URI . '/images/no-image-133x83.jpg';
        }

        if ( $next && has_post_thumbnail( $next->ID ) ) {
            $nextthumb = wp_get_attachment_image_src( get_post_thumbnail_id( $next->ID ), 'hcode-navigation-img' );
            if($nextthumb[0]):
                $next_image = $nextthumb[0];
            else:
                $next_image = HCODE_THEME_ASSETS_URI . '/images/no-image-133x83.jpg';
            endif;
        }else{
        	$next_image = HCODE_THEME_ASSETS_URI . '/images/no-image-133x83.jpg';
        }
        ?>
        <?php
        $related_post_style = hcode_option( 'enable_navigation_style' );    
        
        if( $related_post_style == 'normal' ){ 
        ?>
            <div class="next-previous-project-style2" role="navigation">
                <!-- next-previous post -->
                <div class="previous-link"><?php previous_post_link( '%link', '<i class="fa fa-angle-left"></i>&nbsp;'.wp_kses('<span>Previous Post</span>') ); ?></div>
                <div class="back-to-category">
                    <a href="<?php echo $link;?>" class="border-right text-uppercase back-project">
                        <i class="fa fa-th-large"></i>
                    </a>
                </div>
                <div class="next-link"><?php next_post_link( '%link', wp_kses('<span>Next Post</span>').'&nbsp;<i class="fa fa-angle-right"></i>' );?></div>
                <!-- end next-previous post -->
            </div>
        <?php }
        elseif($related_post_style == 'modern'){ ?>
            <div class="next-previous-project xs-display-none">
                <div class="next-project">
                    <?php next_post_link( '%link', '<img alt="Next Post" class="next-project-img" src="'.HCODE_THEME_ASSETS_URI.'/images/next-project.png" width="33" height="83"><span>'.esc_html__( 'Next Post','H-Code').'</span><!-- next post image --><img alt="Next Post" src="'.$next_image.'">' );?>
                </div>
                <div class="previous-project">
                    <?php previous_post_link( '%link', '<img alt="Previous Post" src="'.$prev_image.'"><img alt="Previous Post" class="previous-project-img" src="'.HCODE_THEME_ASSETS_URI.'/images/previous-project.png" width="33" height="83"><span>'.esc_html__( 'Previous Post','H-Code').'</span>' ); ?>
                </div>
            </div>
        <?php }
    }
endif;

/* Post Navigation */
if ( ! function_exists( 'hcode_single_portfolio_navigation' ) ) :

    function hcode_single_portfolio_navigation() {
        // Don't print empty markup if there's nowhere to navigate.
        
        $previous = ( is_attachment() ) ? get_post( get_post()->post_parent ) : get_adjacent_post( false, '', true );
        $next     = get_adjacent_post( false, '', false );

        if ( ! $next && ! $previous ) {
            return;
        }
        if ( is_attachment() && 'attachment' == $previous->post_type ) {
            return;
        }
        $link = $cat_name = $next_image = $prev_image = '';

        $terms = get_the_terms( get_the_ID() , 'portfolio-category' );
        if( $terms ){
            $link = get_term_link($terms[0]->slug,'portfolio-category');
            $cat_name = get_term_link($terms[0]->name,'portfolio-category');
        }
        if ( $previous &&  has_post_thumbnail( $previous->ID ) ) {
            $prevthumb = wp_get_attachment_image_src( get_post_thumbnail_id( $previous->ID ), 'hcode-navigation-img' );
            if($prevthumb[0]):
                $prev_image = $prevthumb[0];
            else:
                $prev_image = HCODE_THEME_ASSETS_URI . '/images/no-image-133x83.jpg';
            endif;
        }else{
        	$prev_image = HCODE_THEME_ASSETS_URI . '/images/no-image-133x83.jpg';
        }

        if ( $next && has_post_thumbnail( $next->ID ) ) {
            $nextthumb = wp_get_attachment_image_src( get_post_thumbnail_id( $next->ID ), 'hcode-navigation-img' );
            if($nextthumb[0]):
                $next_image = $nextthumb[0];
            else:
                $next_image = HCODE_THEME_ASSETS_URI . '/images/no-image-133x83.jpg';
            endif;
        }else{
        	$next_image = HCODE_THEME_ASSETS_URI . '/images/no-image-133x83.jpg';
        }
        ?>
        <?php
        $related_portfolio_style = hcode_option( 'enable_navigation_portfolio_style' );
        if( $related_portfolio_style == 'normal' ){ ?>
            <div class="next-previous-project-style2" role="navigation">
                <!-- next-previous post -->
                <div class="previous-link"><?php previous_post_link( '%link', '<i class="fa fa-angle-left"></i>&nbsp;'.wp_kses('<span>Previous Post</span>', 'H-Code') ); ?></div>
                <div class="back-to-category">
                    <a href="<?php echo $link;?>" class="border-right text-uppercase back-project">
                        <i class="fa fa-th-large"></i>
                    </a>
                </div>
                <div class="next-link"><?php next_post_link( '%link', wp_kses('<span>Next Post</span>').'&nbsp;<i class="fa fa-angle-right"></i>' );?></div>
                <!-- end next-previous post -->
            </div>
        <?php }
        elseif($related_portfolio_style == 'modern'){ ?>
            <div class="next-previous-project xs-display-none">
                <div class="next-project">
                    <?php next_post_link( '%link', '<img alt="Next Project" class="next-project-img" src="'.HCODE_THEME_ASSETS_URI.'/images/next-project.png" width="33" height="83"><span>'.esc_html__( 'Next Project','H-code').'</span><!-- next project image --><img alt="Next Project" src="'.$next_image.'">' );?>
                </div>
                <div class="previous-project">
                    <?php previous_post_link( '%link', '<img alt="Previous Project" src="'.$prev_image.'"><img alt="Previous Project" class="previous-project-img" src="'.HCODE_THEME_ASSETS_URI.'/images/previous-project.png" width="33" height="83"><span>'.esc_html__( 'Previous Project','H-code').'</span>' ); ?>
                </div>
            </div>
            <?php }?>
        <?php
    }
endif;

/* For Adding Class Into Single Post Pagination*/
if ( ! function_exists( 'hcode_posts_link_next_class' ) ) {
    function hcode_posts_link_next_class($format){
         $format = str_replace('href=', 'class="next" href=', $format);
         return $format;
    }
}
add_filter('next_post_link', 'hcode_posts_link_next_class');

if ( ! function_exists( 'hcode_posts_link_prev_class' ) ) {
    function hcode_posts_link_prev_class($format) {
         $format = str_replace('href=', 'class="previous" href=', $format);
         return $format;
    }
}
add_filter('previous_post_link', 'hcode_posts_link_prev_class');

/* Single blog page related post */
/* Post Navigation */
if ( ! function_exists( 'hcode_single_post_related_posts' ) ) :

    function hcode_single_post_related_posts( $post_type = 'post', $number_posts = '3') {

        global $post;
        $args = $output = $title = '';
        $hcode_options = get_option( 'hcode_theme_setting' ); 
        
        $title = (isset($hcode_options['hcode_related_post_title'])) ? $hcode_options['hcode_related_post_title'] : '';
        $recent_post = new WP_Query();

        if( $number_posts == 0 ) {
            return $recent_post;
        }

        $args = array(
            'category__in'          => wp_get_post_categories( get_the_ID() ),
            'ignore_sticky_posts'   => 0,
            'posts_per_page'        => $number_posts,
            'post__not_in'          => array( get_the_ID() ),
        );

        $recent_post = new WP_Query( $args );
        if ( $recent_post->have_posts() ) {
            $enable_comment = hcode_option('hcode_enable_post_comment');
            if( $enable_comment == 'default' ):
                $hcode_enable_portfolio_comment = (isset($hcode_options['hcode_enable_post_comment'])) ? $hcode_options['hcode_enable_post_comment'] : '';
            else:
                $hcode_enable_portfolio_comment = $enable_comment;
            endif;
            $style_setting = '';
            if($hcode_enable_portfolio_comment == 1):
                $style_setting = 'border-top xs-no-padding-bottom xs-padding-five-top';
            else:
                $style_setting = 'xs-no-margin xs-no-padding';
            endif;
            
            $output .= '<section class="no-padding clear-both"><div class="container"><div class="row">';
            $output .= '<div class="wpb_column vc_column_container col-md-12 no-padding"><div class="hcode-divider '.$style_setting.' margin-five-top padding-five-bottom"></div></div>';
            $output .= '<div class="col-md-12 col-sm-12 center-col text-center margin-eight no-margin-top xs-padding-ten-top">';
                $output .= '<h3 class="blog-single-full-width-h3">'.$title.'</h3>';
            $output .= '</div>';
            $output .= '<div class="blog-grid-listing padding-ten-bottom col-md-12 col-sm-12 col-xs-12 no-padding">';
            $i=1;
            while ( $recent_post->have_posts() ) {
                $wow_duration = ($i * 300).'ms';
                $output .= '<div class="col-md-4 col-sm-4 col-xs-12 blog-listing no-margin-bottom xs-margin-bottom-ten wow fadeInUp animated" data-wow-duration="'.$wow_duration.'" style="visibility: visible; animation-duration: 300ms; animation-name: fadeInUp;">';
                $recent_post->the_post();

                    $url = wp_get_attachment_url( get_post_thumbnail_id(get_the_ID()) );
                    $post_author = get_post_field( 'post_author', get_the_ID() );
                    $author = get_the_author_meta( 'user_nicename', $post_author);
                    $author = ($author) ? esc_html__('Posted by ','H-Code').$author : '';
                    $blog_quote = hcode_post_meta('hcode_quote');
                    $blog_image = hcode_post_meta('hcode_image');
                    $blog_gallery = hcode_post_meta('hcode_gallery');
                    $blog_video = hcode_post_meta('hcode_video_type');
                    if(!empty($blog_image)){
                        if($blog_image == 1){
                            $output .= '<div class="blog-image"><a href="'.get_permalink().'">';
                                    if ( has_post_thumbnail() ) {
                                            $output .= get_the_post_thumbnail(get_the_ID() ,'hcode-related-post' );
                                    }
                                    else {
                                            $output .= '<img src="' . HCODE_THEME_ASSETS_URI . '/images/no-image-374x234.jpg" width="374" height="234" alt=""/>';
                                    }
                            $output .= '</a></div>';
                        }
                    }
                    else{
                        $thumb = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'full' );
                        $url = $thumb['0'];
                        $output .='<div class="blog-image"><a href="'.get_permalink().'">';
                        if ( has_post_thumbnail() ) {
                            $output .= get_the_post_thumbnail( get_the_ID(), 'hcode-related-post' );
                        }
                        else {
                                $output .= '<img src="' . HCODE_THEME_ASSETS_URI . '/images/no-image-374x234.jpg" width="374" height="234" alt=""/>';
                        }
                        $output .='</a></div>';
                    }
                    $output .='<div class="blog-details no-padding">';
                        $output .='<div class="blog-date">'.$author.' | '.get_the_date('d F Y', get_the_ID()).'</div>';
                            $output .='<div class="blog-title"><a href="'.get_permalink().'">'.get_the_title().'</a></div>';
                        $output .='<div class="blog-short-description">'.strip_shortcodes(wp_trim_words( get_the_content() , '30' )).'</div>';
                        $output .='<div class="separator-line bg-black no-margin-lr"></div>';
                    $output .='</div>';
                    $output .= '<div>';
                        $output .= get_simple_likes_button( get_the_ID() );
                        ob_start();
                            comments_popup_link( __( '<i class="fa fa-comment-o"></i>Leave a comment', 'H-Code' ), __( '<i class="fa fa-comment-o"></i>1 Comment', 'H-Code' ), __( '<i class="fa fa-comment-o"></i>% Comment(s)', 'H-Code' ), 'comment' );
                            $output .= ob_get_contents();  
                        ob_end_clean();
                    $output .= '</div>';
                $output .=  '</div>';
                $i++;
            }
            $output .=  '</div>';
            $output .= '</div></div></section>';
        echo $output;
        }
    }
endif;

/* Single Portfolio Related Items */
if ( ! function_exists( 'hcode_single_portfolio_related_posts' ) ) :

    function hcode_single_portfolio_related_posts( $post_type = 'portfolio', $number_posts = '3') {
        global $post;
        $args = $output = '';
        $related_post_terms = array();    
        $hcode_options = get_option( 'hcode_theme_setting' ); 
       
        $title = (isset($hcode_options['hcode_related_title'])) ? $hcode_options['hcode_related_title'] : '';

        $recent_post = new WP_Query();

        if( $number_posts == 0 ) {
            return $recent_post;
        }
        $terms = get_the_terms( get_the_ID() , 'portfolio-category' );
        if( $terms ):
            foreach ($terms as $key => $value) {
                $related_post_terms[] = $value->term_id;
            }
        endif;
        $args = array(
            'post_type' => $post_type,
            'posts_per_page' => $number_posts,        
            'post__not_in' => array( get_the_ID() ),
            'tax_query' => array(
                array(
                'taxonomy' => 'portfolio-category',
                'terms' => $related_post_terms,
                'field' => 'term_id',
                ),
            ),
            'meta_query' => array(
                array(
                    'key'       => 'hcode_link_type_single',
                    'value'     => 'ajax-popup',
                    'compare'   => '!=',
                )
            )
        );

        $recent_post = new WP_Query( $args );
        if ( $recent_post->have_posts() ) {
            $hcode_options = get_option( 'hcode_theme_setting' );
            $enable_comment = hcode_option('hcode_enable_portfolio_comment');
            if( $enable_comment == 'default' ):
                $hcode_enable_portfolio_comment = (isset($hcode_options['hcode_enable_portfolio_comment'])) ? $hcode_options['hcode_enable_portfolio_comment'] : '';
            else:
                $hcode_enable_portfolio_comment = $enable_comment;
            endif;

            $output .= '<div class="wpb_column vc_column_container col-md-12 no-padding"><div class="hcode-divider border-top sm-padding-five-top xs-padding-five-top padding-five-bottom"></div></div><section class="clear-both no-padding-top"><div class="container"><div class="row">';
            $output .= '<div class="col-md-12 col-sm-12 text-center">';
                $output .= '<h3 class="section-title">'.$title.'</h3>';
            $output .= '</div>';
            $output .='<div class="work-3col gutter work-with-title ipad-3col">';
                $output .='<div class="col-md-12 grid-gallery overflow-hidden content-section">';
                    $output .='<div class="tab-content">';
                        $output .='<ul class="grid masonry-items">';
                    while ( $recent_post->have_posts() ) : $recent_post->the_post();
                        $output .='<li class="portfolio-id-'.get_the_ID().'">';
                            $output .='<figure>';
                                $portfolio_image = hcode_post_meta('hcode_image');
                                $portfolio_gallery = hcode_post_meta('hcode_gallery');
                                $portfolio_link = hcode_post_meta('hcode_link_type');
                                $portfolio_video = hcode_post_meta('hcode_video');
                                $portfolio_subtitle = hcode_post_meta('hcode_subtitle');
                                if(!empty($portfolio_image)){
                                    if($portfolio_image == 1){
                                        $thumb = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'hcode-related-post' );
                                        $url = $thumb['0'];
                                        if($url):
                                            $output .= '<div class="gallery-img">';
                                                $output .= '<a href="'.get_permalink().'">';
                                                    $output .= '<img src="' . $url . '" width="'.$thumb[1].'" height="'.$thumb[2].'" alt=""/>';
                                                $output .= '</a>';
                                            $output .= '</div>';
                                        else : 
                                            $output .= '<div class="gallery-img">';
                                                $output .= '<a href="'.get_permalink().'">';
                                                    $output .= '<img src="' . HCODE_THEME_ASSETS_URI . '/images/no-image-374x234.jpg" width="374" height="234"/>';
                                                $output .= '</a>';
                                            $output .= '</div>';
                                        endif;
                                    }  
                                }else{
                                        $thumb = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'hcode-related-post' );
                                        $url = $thumb['0'];
                                        $output .= '<div class="gallery-img">';
                                            $output .= '<a href="'.get_permalink().'">';
                                                if ( $url ) {
                                                    $output .= '<img src="' . $url . '" width="'.$thumb[1].'" height="'.$thumb[2].'" alt=""/>';
                                                }
                                                else {
                                                    $output .= '<img src="' . HCODE_THEME_ASSETS_URI . '/images/no-image-374x234.jpg" width="374" height="234"/>';
                                                }
                                            $output .= '</a>';
                                        $output .= '</div>';
                                        
                                }
                                $output .= '<figcaption>';
                                    $output .= '<h3><a href="'.get_permalink().'">'.get_the_title().'</a></h3>';
                                    $output .= '<p>'.$portfolio_subtitle.'</p>';
                                $output .= '</figcaption>';
                            $output .='</figure>';
                        $output .='</li>';
                    endwhile;
                        $output .='</ul>';
                    $output .='</div>';
                $output .='</div>';
            $output .='</div>';
            $output .= '</div></div></section>';
        echo $output;
        }
    }
endif;

if ( ! function_exists( 'hcode_posts_customize' ) ) {
    function hcode_posts_customize($query) {
        $hcode_options = get_option( 'hcode_theme_setting' );
        if( !is_admin() && $query->is_main_query()):
            if(class_exists( 'WooCommerce' )){
                if ((is_category() || is_archive() || is_author() || is_tag()) && !is_product_category()) {
                    if ( get_query_var('paged') ) { $paged = get_query_var('paged'); } else if ( get_query_var('page') ) {$paged = get_query_var('page'); } else {$paged = 1; }
                    $hcode_item_per_page = (isset($hcode_options['hcode_general_item_per_page'])) ? $hcode_options['hcode_general_item_per_page'] : '';
                    $query->set('posts_per_page', $hcode_item_per_page);
                    $query->set('paged', $paged);
                }
            }else{
                if ((is_category() || is_archive() || is_author() || is_tag())) {
                    if ( get_query_var('paged') ) { $paged = get_query_var('paged'); } else if ( get_query_var('page') ) {$paged = get_query_var('page'); } else {$paged = 1; }
                    $hcode_item_per_page = (isset($hcode_options['hcode_general_item_per_page'])) ? $hcode_options['hcode_general_item_per_page'] : '';
                    $query->set('posts_per_page', $hcode_item_per_page);
                    $query->set('paged', $paged);
                }
            }
            
            if(is_search()):
                if ( get_query_var('paged') ) { $paged = get_query_var('paged'); } else if ( get_query_var('page') ) {$paged = get_query_var('page'); } else {$paged = 1; }
                $hcode_item_per_page = (isset($hcode_options['hcode_general_item_per_page'])) ? $hcode_options['hcode_general_item_per_page'] : '';
                $query->set('posts_per_page', $hcode_item_per_page);
                $query->set('paged', $paged);
                $search_content = (isset($hcode_options['hcode_general_search_content_settings'])) ? $hcode_options['hcode_general_search_content_settings'] : '';
                if($search_content == 'only-post'){
                    $query->set('post_type', 'post');
                }elseif($search_content == 'only-page'){
                    $query->set('post_type', 'page');
                }else{
                    $query->set('post_type', array('page','post'));
                }
                
            endif;
            if(is_tax('portfolio-category')):
                $hcode_item_per_page = (isset($hcode_options['hcode_portfolio_cat_item_per_page'])) ? $hcode_options['hcode_portfolio_cat_item_per_page'] : '';
                $query->set('posts_per_page', $hcode_item_per_page);
            endif;
        endif;
    } 
}
add_action('pre_get_posts', 'hcode_posts_customize');

if ( ! function_exists( 'hcode_get_the_excerpt_theme' ) ) {
    function hcode_get_the_excerpt_theme($length)
    {
        return hcode_Excerpt::hcode_get_by_length($length);
    }
}

if ( ! function_exists( 'hcode_widgets' ) ) {
    function hcode_widgets() {
        $custom_sidebars = hcode_option('sidebar_creation');
        if (is_array($custom_sidebars)) {
            foreach ($custom_sidebars as $sidebar) {

                if (empty($sidebar)) {
                    continue;
                }

                register_sidebar ( array (
                    'name' => $sidebar,
                    'id' => sanitize_title ( $sidebar ),
                    'before_widget' => '<div id="%1$s" class="custom-widget %2$s">',
                    'after_widget' => '</div>',
                    'before_title'  => '<h5 class="sidebar-title">',
                    'after_title'   => '</h5>',
                ) );
            }
        }
    }
}
add_action( 'widgets_init', 'hcode_widgets' );

/* For contact Form 7 select default */
if ( ! function_exists( 'hcode_wpcf7_form_elements' ) ) {
    function hcode_wpcf7_form_elements($html) {
        $text = "Select Position";
        $html = str_replace('---', '' . $text . '', $html);
        return $html;
    }
}
add_filter('wpcf7_form_elements', 'hcode_wpcf7_form_elements');

/* For Wordpress4.4 move comment textarea bottom */
if ( ! function_exists( 'hcode_move_comment_field_to_bottom' ) ) {
    function hcode_move_comment_field_to_bottom( $fields ) {
        $comment_field = $fields['comment'];
        unset( $fields['comment'] );
        $fields['comment'] = $comment_field;
        return $fields;
    }
}
add_filter( 'comment_form_fields', 'hcode_move_comment_field_to_bottom' );

if ( ! function_exists( 'hcode_get_sidebar' ) ) {
    function hcode_get_sidebar($sidebar_name="0"){
        if($sidebar_name != "0"){
            dynamic_sidebar($sidebar_name);
        }else{
            dynamic_sidebar('hcode-sidebar-1');
        }
    }
}

/* Hook For ajax page */
if ( ! function_exists( 'hcode_hook_for_ajax_page' ) ) {
    function hcode_hook_for_ajax_page() {
        
        $output="<script>
        'use strict';
        $(document).ready(function () {
                $('.owl-pagination > .owl-page').click(function (e) {
                    if ($(e.target).is('.mfp-close'))
                        return;
                    return false;
                });
                $('.owl-buttons > .owl-prev').click(function (e) {
                    if ($(e.target).is('.mfp-close'))
                        return;
                    return false;
                });
                $('.owl-buttons > .owl-next').click(function (e) {
                    if ($(e.target).is('.mfp-close'))
                        return;
                    return false;
                });

            SetResizeContent();
            });

            function SetResizeContent() {
                var minheight = $(window).height();
                $('.full-screen').css('min-height', minheight);
            }
            </script>";

        echo $output;
    }
}

/* If Font Icon Not Available add from here */
if( !function_exists('hcode_get_font_awesome_icon')) {
  function hcode_get_font_awesome_icon() {
    $fa_icons = array('fa-adjust','fa-adn','fa-align-center','fa-align-justify','fa-align-left', 'fa-align-right','fa-ambulance','fa-anchor','fa-android','fa-angle-double-down','fa-angle-double-left','fa-angle-double-right','fa-angle-double-up','fa-angle-down', 'fa-angle-left','fa-angle-right','fa-angle-up','fa-apple','fa-archive','fa-arrow-circle-down','fa-arrow-circle-left','fa-arrow-circle-o-down','fa-arrow-circle-o-left','fa-arrow-circle-o-right','fa-arrow-circle-o-up','fa-arrow-circle-right','fa-arrow-circle-up','fa-arrow-down','fa-arrow-left','fa-arrow-right','fa-arrow-up','fa-arrows','fa-arrows-alt','fa-arrows-h','fa-arrows-v','fa-asterisk','fa-automobile','fa-backward','fa-ban','fa-bank','fa-bar-chart-o','fa-barcode','fa-bars','fa-beer','fa-behance','fa-behance-square','fa-bellfa-bell-o','fa-bitbucket','fa-bitbucket-square','fa-bitcoin','fa-bold','fa-bolt','fa-bomb','fa-book','fa-bookmark','fa-bookmark-o','fa-briefcase','fa-btc','fa-bug','fa-building','fa-building-o','fa-bullhorn','fa-bullseye','fa-cab','fa-calendar','fa-calendar-o','fa-camera','fa-camera-retro','fa-car','fa-caret-down','fa-caret-left','fa-caret-right','fa-caret-square-o-down','fa-caret-square-o-left','fa-caret-square-o-right','fa-caret-square-o-up','fa-caret-up','fa-certificate','fa-chain','fa-chain-broken','fa-check','fa-check-circle','fa-check-circle-o','fa-check-square','fa-check-square-o','fa-chevron-circle-down','fa-chevron-circle-left','fa-chevron-circle-right','fa-chevron-circle-up','fa-chevron-down','fa-chevron-left','fa-chevron-right','fa-chevron-up','fa-child','fa-circle','fa-circle-o','fa-circle-o-notch','fa-circle-thin','fa-clipboard','fa-clock-o','fa-cloud','fa-cloud-download','fa-cloud-upload','fa-cny','fa-code','fa-code-fork','fa-codepen','fa-coffee','fa-cog','fa-cogs','fa-columns','fa-comment','fa-comment-o','fa-comments','fa-comments-o','fa-compass','fa-compress','fa-copy','fa-credit-card','fa-crop','fa-crosshairs','fa-css3','fa-cube','fa-cubes','fa-cut','fa-cutlery','fa-dashboard','fa-database','fa-dedent','fa-delicious','fa-desktop','fa-deviantart','fa-digg','fa-dollar','fa-dot-circle-o','fa-download','fa-dribbble','fa-dropbox','fa-drupal','fa-edit','fa-eject','fa-ellipsis-h','fa-ellipsis-v','fa-empire','fa-envelope','fa-envelope-o','fa-envelope-square','fa-eraser','fa-eur','fa-euro','fa-exchange','fa-exclamation','fa-exclamation-circle','fa-exclamation-triangle','fa-expand','fa-external-link','fa-external-link-square','fa-eye','fa-eye-slash','fa-facebook','fa-facebook-square','fa-fast-backward','fa-fast-forward','fa-fax','fa-female','fa-fighter-jet','fa-file','fa-file-archive-o','fa-file-audio-o','fa-file-code-o','fa-file-excel-o','fa-file-image-o','fa-file-movie-o','fa-file-o','fa-file-pdf-o','fa-file-photo-o','fa-file-picture-o','fa-file-powerpoint-o','fa-file-sound-o','fa-file-text','fa-file-text-o','fa-file-video-o','fa-file-word-o','fa-file-zip-o','fa-files-o','fa-film','fa-filter','fa-fire','fa-fire-extinguisher','fa-flag','fa-flag-checkered','fa-flag-o','fa-flash','fa-flask','fa-flickr','fa-floppy-o','fa-folder','fa-folder-o','fa-folder-open','fa-folder-open-o','fa-font','fa-forward','fa-foursquare','fa-frown-o','fa-gamepad','fa-gavel','fa-gbp','fa-ge','fa-gear','fa-gears','fa-gift','fa-git','fa-git-square','fa-github','fa-github-alt','fa-github-square','fa-gittip','fa-glass','fa-globe','fa-google','fa-google-plus','fa-google-plus-square','fa-graduation-cap','fa-group','fa-h-square','fa-hacker-news','fa-hand-o-down','fa-hand-o-left','fa-hand-o-right','fa-hand-o-up','fa-hdd-o','fa-header','fa-headphones','fa-heart','fa-heart-o','fa-history','fa-home','fa-hospital-o','fa-html5','fa-image','fa-inbox','fa-indent','fa-info','fa-info-circle','fa-inr','fa-instagram','fa-institution','fa-italic','fa-joomla','fa-jpy','fa-jsfiddle','fa-key','fa-keyboard-o','fa-krw','fa-language','fa-laptop','fa-leaf','fa-legal','fa-lemon-o','fa-level-down','fa-level-up','fa-life-bouy','fa-life-ring','fa-life-saver','fa-lightbulb-o','fa-link','fa-linkedin','fa-linkedin-square','fa-linux','fa-list','fa-list-alt','fa-list-ol','fa-list-ul','fa-location-arrow','fa-lock','fa-long-arrow-down','fa-long-arrow-left','fa-long-arrow-right','fa-long-arrow-up','fa-magic','fa-magnet','fa-mail-forward','fa-mail-reply','fa-mail-reply-all','fa-male','fa-map-marker','fa-maxcdn','fa-medkit','fa-meh-o','fa-microphone','fa-microphone-slash','fa-minus','fa-minus-circle','fa-minus-square','fa-minus-square-o','fa-mobile','fa-mobile-phone','fa-money','fa-moon-o','fa-mortar-board','fa-music','fa-navicon','fa-openid','fa-outdent','fa-pagelines','fa-paper-plane','fa-paper-plane-o','fa-paperclip','fa-paragraph','fa-paste','fa-pause','fa-paw','fa-pencil','fa-pencil-square','fa-pencil-square-o','fa-phone','fa-phone-square','fa-photo','fa-picture-o','fa-pied-piper','fa-pied-piper-alt','fa-pied-piper-square','fa-pinterest','fa-pinterest-square','fa-plane','fa-play','fa-play-circle','fa-play-circle-o','fa-plus','fa-plus-circle','fa-plus-square','fa-plus-square-o','fa-power-off','fa-print','fa-puzzle-piece','fa-qq','fa-qrcode','fa-question','fa-question-circle','fa-quote-left','fa-quote-right','fa-ra','fa-random','fa-rebel','fa-recycle','fa-reddit','fa-reddit-square','fa-refresh','fa-renren','fa-reorder','fa-repeat','fa-reply','fa-reply-all','fa-retweet','fa-rmb','fa-road','fa-rocket','fa-rotate-left','fa-rotate-right','fa-rouble','fa-rss','fa-rss-square','fa-rub','fa-ruble','fa-rupee','fa-save','fa-scissors','fa-search','fa-search-minus','fa-search-plus','fa-send','fa-send-o','fa-share','fa-share-alt','fa-share-alt-square','fa-share-square','fa-share-square-o','fa-shield','fa-shopping-cart','fa-sign-in','fa-sign-out','fa-signal','fa-sitemap','fa-skype','fa-slack','fa-sliders','fa-smile-o','fa-sort','fa-sort-alpha-asc','fa-sort-alpha-desc','fa-sort-amount-asc','fa-sort-amount-desc','fa-sort-asc','fa-sort-desc','fa-sort-down','fa-sort-numeric-asc','fa-sort-numeric-desc','fa-sort-up','fa-soundcloud','fa-space-shuttle','fa-spinner','fa-spoon','fa-spotify','fa-square','fa-square-o','fa-stack-exchange','fa-stack-overflow','fa-star','fa-star-half','fa-star-half-empty','fa-star-half-full','fa-star-half-o','fa-star-o','fa-steam','fa-steam-square','fa-step-backward','fa-step-forward','fa-stethoscope','fa-stop','fa-strikethrough','fa-stumbleupon','fa-stumbleupon-circle','fa-subscript','fa-suitcase','fa-sun-o','fa-superscript','fa-support','fa-table','fa-tablet','fa-tachometer','fa-tag','fa-tags','fa-tasks','fa-taxi','fa-tencent-weibo','fa-terminal','fa-text-height','fa-text-width','fa-th','fa-th-large','fa-th-list','fa-thumb-tack','fa-thumbs-down','fa-thumbs-o-down','fa-thumbs-o-up','fa-thumbs-up','fa-ticket','fa-times','fa-times-circle','fa-times-circle-o','fa-tint','fa-toggle-down','fa-toggle-left','fa-toggle-right','fa-toggle-up','fa-trash-o','fa-tree','fa-trello','fa-trophy','fa-truck','fa-try','fa-tumblr','fa-tumblr-square','fa-turkish-lira','fa-twitter','fa-twitter-square','fa-umbrella','fa-underline','fa-undo','fa-university','fa-unlink','fa-unlock','fa-unlock-alt','fa-unsorted','fa-upload','fa-usd','fa-user','fa-user-md','fa-users','fa-video-camera','fa-vimeo-square','fa-vine','fa-vk','fa-volume-down','fa-volume-off','fa-volume-up','fa-warning','fa-wechat','fa-weibo','fa-weixin','fa-wheelchair','fa-windows','fa-won','fa-wordpress','fa-wrench','fa-xing','fa-xing-square','fa-yahoo','fa-yen','fa-youtube','fa-youtube-play','fa-youtube-square');
    return $fa_icons;
  }
}

// Remove Empty P tag

if( ! function_exists( 'hcode_remove_wpautop' ) ) {
  function hcode_remove_wpautop( $content, $force_br = true ) {
    if ( $force_br ) {
      $content = wpautop( preg_replace( '/<\/?p\>/', "\n", $content ) . "\n" );
    }
    return do_shortcode( shortcode_unautop( $content ) );
  }
}

// Post Meta
if ( ! function_exists( 'hcode_single_post_meta' ) ) :

    function hcode_single_post_meta() {

        if ( 'post' == get_post_type() || 'portfolio' == get_post_type() ) {
            if ( is_singular() || is_multi_author() ) {
                printf( '%1$s <a class="url fn n" href="%2$s">%3$s</a>',
                    esc_html__( 'Posted by ', 'H-Code' ),
                    esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
                    get_the_author()
                );
            }
        }
        if ( in_array( get_post_type(), array( 'post', 'attachment', 'portfolio' ) ) ) {
            $time_string = '%2$s';

            $time_string = sprintf( $time_string,
                esc_attr( get_the_date( 'c' ) ),
                get_the_date(),
                esc_attr( get_the_modified_date( 'c' ) ),
                get_the_modified_date()
            );

            printf( ' | %1$s',
                $time_string
            );
        }
        if ( 'post' == get_post_type() ) {
            
            $categories_list = get_the_category_list( _x( ', ', 'Used between list items, there is a space after the comma.', 'H-Code' ) );
            if ( $categories_list && hcode_categorized_blog() ) {
                printf( ' | %1$s',
                    $categories_list
                );
            }
        }
        
    }
endif;

// single portfolio meta

if ( ! function_exists( 'hcode_single_portfolio_meta' ) ) :

    function hcode_single_portfolio_meta() {
    $output = '';
    ob_start();
        if ( 'portfolio' == get_post_type() ) {
            if ( is_singular() || is_multi_author() ) {
                printf( '%1$s <a class="url fn n" href="%2$s">%3$s</a>',
                    _x( 'Created by', 'Used before post author name.', 'H-Code' ),
                    esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
                    get_the_author()
                );
            }
        }
        if ( in_array( get_post_type(), array( 'portfolio' ) ) ) {
            $time_string = '%2$s';

            $time_string = sprintf( $time_string,
                esc_attr( get_the_date( 'c' ) ),
                get_the_date(),
                esc_attr( get_the_modified_date( 'c' ) ),
                get_the_modified_date()
            );

            printf( ' | %1$s',
                $time_string
            );
        }

        if ( 'portfolio' == get_post_type() ) {
            $cat = get_the_terms( get_the_ID(), 'portfolio-category' );
            $item = 1;
            $cat_slug = '';
            if(!empty($cat)):
                foreach ($cat as $key => $c) {
                    if( count($cat) == $item){
                        $cat_slug .= '<a href="' . get_term_link( $c ) . '" title="' . sprintf( esc_html__( 'View all post filed under %s', 'my_localization_domain' ), $c->name ) . '">' . $c->name . '</a>';
                    }else{
                        $cat_slug .= '<a href="' . get_term_link( $c ) . '" title="' . sprintf( esc_html__( 'View all post filed under %s', 'my_localization_domain' ), $c->name ) . '">' . $c->name . '</a>, ';
                    }
                    $item++;
                }
            endif;
            if($cat_slug){
                echo ' | '.$cat_slug;
            }
        }
    $output = ob_get_contents();  
    ob_end_clean(); 
    return $output;
    }
endif;

// Blog Full Width Header Meta

if ( ! function_exists( 'hcode_full_width_single_post_meta' ) ) :

function hcode_full_width_single_post_meta() {

    if ( 'post' == get_post_type() ) {
        if ( is_singular() || is_multi_author() ) {
            printf( '<div class="posted-by text-uppercase">%1$s <a class="url fn n white-text" href="%2$s">%3$s</a></div>',
                esc_html__( 'Posted by ', 'H-Code' ),
                esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
                get_the_author()
            );
        }
    }
    printf('<div class="full-blog-date text-uppercase">');
    if ( in_array( get_post_type(), array( 'post', 'attachment' ) ) ) {
        $time_string = '%2$s';

        $time_string = sprintf( $time_string,
            esc_attr( get_the_date( 'c' ) ),
            get_the_date('d F Y')
        );

        printf( ' %s',
            $time_string
        );
    }
    if ( 'post' == get_post_type() ) {
        
                $categories_list = get_the_category_list( _x( ', ', 'Used between list items, there is a space after the comma.', 'H-Code' ) );
        if ( $categories_list && hcode_categorized_blog() ) {
            printf( ' | %1$s',
                $categories_list
            );
        }
    }
    printf('</div>');  
    if ( is_attachment() && wp_attachment_is_image() ) {
        // Retrieve attachment metadata.
        $metadata = wp_get_attachment_metadata();

        printf( '<span class="full-size-link"><span class="screen-reader-text">%1$s </span><a href="%2$s">%3$s &times; %4$s</a></span>',
            _x( 'Full size', 'Used before full size attachment link.', 'H-Code' ),
            esc_url( wp_get_attachment_url() ),
            $metadata['width'],
            $metadata['height']
        );
    }

    if ( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
        echo '<span class="comments-link">';
        comments_popup_link( esc_html__( 'Leave a comment', 'H-Code' ), esc_html__( '1 Comment', 'H-Code' ), esc_html__( '% Comments', 'H-Code' ) );
        echo '</span>';
    }
}
endif;

if ( ! function_exists( 'hcode_categorized_blog' ) ) :
    function hcode_categorized_blog() {
        if ( false === ( $all_the_cool_cats = get_transient( 'hcode_categories' ) ) ) {
            // Create an array of all the categories that are attached to posts.
            $all_the_cool_cats = get_categories( array(
                'fields'     => 'ids',
                'hide_empty' => 1,

                // We only need to know if there is more than one category.
                'number'     => 2,
            ) );

            // Count the number of categories that are attached to the posts.
            $all_the_cool_cats = count( $all_the_cool_cats );

            set_transient( 'hcode_categories', $all_the_cool_cats );
        }

        if ( $all_the_cool_cats > 1 ) {
            // This blog has more than 1 category so hcode_categorized_blog should return true.
            return true;
        } else {
            // This blog has only 1 category so hcode_categorized_blog should return false.
            return false;
        }
    }
endif;

if ( ! function_exists( 'hcode_category_transient_flusher' ) ) :
    function hcode_category_transient_flusher() {
        delete_transient( 'hcode_categories' );
    }
endif;
add_action( 'edit_category', 'hcode_category_transient_flusher' );
add_action( 'save_post',     'hcode_category_transient_flusher' );

// Get the Post Tags

if ( ! function_exists( 'hcode_single_post_meta_tag' ) ) :

    function hcode_single_post_meta_tag() {
    if ( 'post' == get_post_type() ) {

            $tags_list = get_the_tag_list( '', _x( ', ', 'Used between list items, there is a space after the comma.', 'H-Code' ) );
            if ( $tags_list ) {
                printf( '%1$s %2$s',
                    _x( '<h5 class="widget-title margin-one no-margin-top">Tags</h5>', 'Used before tag names.', 'H-Code' ),
                    $tags_list
                );
            }
        }
    }
endif;

// To Get Portfolio Tags

if ( ! function_exists( 'hcode_single_portfolio_meta_tag' ) ) :

    function hcode_single_portfolio_meta_tag() {
    if ( 'portfolio' == get_post_type() ) {

            global $post;
            $portfolio_tag_list = get_the_term_list($post->ID, 'portfolio-tags', '<h5 class="widget-title margin-one no-margin-top">Tags</h5>', ', ', '');
            if($portfolio_tag_list):
                echo '<div class="blog-date float-left width-100 no-padding-top margin-eight no-margin-bottom">';
                echo get_the_term_list($post->ID, 'portfolio-tags', '<h5 class="widget-title margin-one no-margin-top">Tags</h5>', ', ', '');
                echo '</div>';
            endif;
        }
    }
endif;

if ( ! function_exists( 'hcode_login_logo' ) ) :
// To Change Admin Panel Logo.
    function hcode_login_logo() { 
        $admin_logo = hcode_option('hcode_header_logo');
        if( $admin_logo['url'] ):
        ?>
        <style type="text/css">
            .login h1 a {
                background-image: url(<?php echo $admin_logo['url'];?>  );
                background-size: cover;
                height: 48px;
                width: 150px !important;
            }
        </style>
        <?php 
        endif;
    }
endif;
add_action( 'login_enqueue_scripts', 'hcode_login_logo' );

// To Change Admin Panel Logo Url.
if ( ! function_exists( 'hcode_login_logo_url' ) ) :
    function hcode_login_logo_url() {
        return home_url();
    }
endif;
add_filter( 'login_headerurl', 'hcode_login_logo_url' );

// To Change Admin Panel Logo Title.
if ( ! function_exists( 'hcode_login_logo_url_title' ) ) :
    function hcode_login_logo_url_title() {
        $text = get_bloginfo('name').' | '.get_bloginfo('description');
        return $text;
    }
endif;
add_filter( 'login_headertitle', 'hcode_login_logo_url_title' );

// To remove deprecated notice for old functions
add_filter('deprecated_constructor_trigger_error', '__return_false');

// For Title Tag
if ( ! function_exists( '_wp_render_title_tag' ) ) {
    function hcode_theme_slug_render_title() {
    ?>
        <title><?php wp_title( '|', true, 'right' ); ?></title>
    <?php
    }
    add_action( 'wp_head', 'hcode_theme_slug_render_title' );
}

if ( ! function_exists( 'hcode_registered_sidebars_array' ) ) :
function hcode_registered_sidebars_array() {
    global $wp_registered_sidebars;
    if( ! empty( $wp_registered_sidebars ) && is_array( $wp_registered_sidebars ) ){ 
        $sidebar_array = array();
        $sidebar_array['0'] = 'Select Sidebar';
        foreach( $wp_registered_sidebars as $sidebar ){
            $sidebar_array[] = $sidebar['id'];
        }
    }
    return $sidebar_array;
}
endif;

// Check if Hcode-addons Plugin active or not.
if(!class_exists('Hcode_Addons_Post_Type')){
    if ( ! function_exists( 'get_simple_likes_button' ) ) :
        function get_simple_likes_button( $id ) {
            return;
        }
    endif;
}

// Remove VC redirection
if(class_exists('Vc_Manager')){
    remove_action( 'vc_activation_hook', 'vc_page_welcome_set_redirect');
    remove_action( 'admin_init', 'vc_page_welcome_redirect');
}