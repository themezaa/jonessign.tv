<?php
/**
 * H-Code main file for import data.
 *
 * @package H-Code
 */
?>
<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

// Don't resize images for import
if ( ! function_exists( 'hcode_no_image_resize' ) ) :
	function hcode_no_image_resize( $sizes ) {
		return array();
	}
endif;

// Hook For Import Sample Data And Log.
add_action( 'wp_ajax_hcode_import_sample_data', 'hcode_import_sample_data' );
add_action( 'wp_ajax_hcode_refresh_import_log', 'hcode_refresh_import_log' );

if ( ! function_exists( 'hcode_import_sample_data' ) ) :
	function hcode_import_sample_data() {
		global $wpdb;

		if ( current_user_can( 'manage_options' ) ) {

			// Load WP Importer
			if ( !defined('WP_LOAD_IMPORTERS') ) define('WP_LOAD_IMPORTERS', true); // we are loading importers

			// Check if main importer class doesn't exist
			if ( ! class_exists( 'WP_Importer' ) ) {
				$wp_importer = ABSPATH . 'wp-admin/includes/class-wp-importer.php';
				include $wp_importer;
			}

			// if WP importer doesn't exist
			if ( ! class_exists('WP_Import') ) {
				$wp_import = HCODE_THEME_IMPORTER . '/wordpress-importer.php';
				include $wp_import;
			}

			$widgets_file = HCODE_THEME_IMPORTER_SAMPLEDATA . '/widget_data.json';

			if ( class_exists( 'WP_Importer' ) && class_exists( 'WP_Import' ) ) { // check for main import class and wp import class.

				hcode_log('', false);

				// Theme Option file.
				$theme_options_file = HCODE_THEME_IMPORTER_SAMPLEDATA . '/theme_options.txt';

				// Register Custom Sidebars.
				$sidebar_exists = true;
				$sidebars = array( 'FooterSocialIcons' => 'Footer Social Icons' );

				// Get Revolution Slider Dir.
				$rev_directory = HCODE_THEME_IMPORTER_SAMPLEDATA . '/revsliders/';

				// reading settings
				$homepage_title = 'Home main';
				
				add_filter('intermediate_image_sizes_advanced', 'hcode_no_image_resize');
				
				/* Import Woocommerce data if WooCommerce Plugin Exists and Active */
				if( class_exists('Woocommerce') ) {

					// Sample Data Zip.
					$sample_data_xml = HCODE_THEME_IMPORTER_SAMPLEDATA . '/H-Code.xml';

					// Sidebar Widgets Json File.
					$widgets_file = HCODE_THEME_IMPORTER_SAMPLEDATA . '/widget_data.json';

					//Before Import Sample Data Add Woocommerce Attribute
					$transient_name = 'wc_attribute_taxonomies';
					$old_attribute_taxonomies = $wpdb->get_results( "SELECT * FROM " . $wpdb->prefix . "woocommerce_attribute_taxonomies" );
					if(empty($old_attribute_taxonomies)){
						hcode_log('MESSAGE - WooCommerce Before Import Sample Data Add Woocommerce Attributes Start.');
						
						require_once( HCODE_ADDONS_ROOT.'/hcode-addons-require-file.php' );
						$attribute_taxonomies_data = new Hcode_Set_attribute_taxonomies;
						$getresultdata = $attribute_taxonomies_data->add_woocommerce_attribute_taxonomies();

						hcode_log('MESSAGE - WooCommerce Before Import Sample Data Add Woocommerce Attributes End.');
					}

					// Import Sample Data XML.
					$importer = new WP_Import();
					// Import Posts, Pages, Portfolio Content, Images, Menus
					$importer->fetch_attachments = true;
					ob_start();
					hcode_log('MESSAGE - H-Code.xml Import Start.');
					$importer->import($sample_data_xml);
					ob_end_clean();
					hcode_log('MESSAGE - H-Code.xml Import End');
					
					hcode_log('MESSAGE - Import WooCommerce Pages Setting Start.');
					// Set Woocommerce Default Pages.
					$woopages = array(
						'woocommerce_shop_page_id' => 'shop',
						'woocommerce_cart_page_id' => 'shopping cart',
						'woocommerce_checkout_page_id' => 'checkout',
						'woocommerce_myaccount_page_id' => 'my-account',
						'woocommerce_lost_password_page_id' => 'lost-password',
						'woocommerce_edit_address_page_id' => 'edit-address',
						'woocommerce_view_order_page_id' => 'view-order',
						'woocommerce_change_password_page_id' => 'change-password',
						'woocommerce_logout_page_id' => 'logout',	
						'woocommerce_pay_page_id' => 'pay',
						'woocommerce_thanks_page_id' => 'order-received'
					);
					foreach($woopages as $woo_page_name => $woo_page_title) {
						$woopage = get_page_by_title( $woo_page_title );
						if(isset( $woopage ) && $woopage->ID) {
							update_option($woo_page_name, $woopage->ID); // Front Page
						}
					}
					hcode_log('MESSAGE - Import WooCommerce Pages Setting End.');

					// We no longer need to install pages.
					delete_option( '_wc_needs_pages' );
						

					// Add Image In Woocommerce Category.
					hcode_log('MESSAGE - Set WooCommerce Category Image Start.');
					$product_categories = get_terms( 'product_cat');
					$attachment_image = hcode_wp_get_attachment_by_post_name( 'parallax-img47' );
					
					foreach ($product_categories as $key => $value) {
						if( $attachment_image ){
							update_woocommerce_term_meta( $value->term_id, 'thumbnail_id', $attachment_image->ID );
						}
					}
					hcode_log('MESSAGE - Set WooCommerce Category Image End.');

					// Add Image/Logo In Woocommerce Brands.
					hcode_log('MESSAGE - Set WooCommerce Brand Logo And Image Start.');
					$brandlogo = 1;
					$product_brands = get_terms( 'product_brand');
					foreach ($product_brands as $key => $value) {
						if( $attachment_image ){
							update_woocommerce_term_meta( $value->term_id, 'thumbnail_id', $attachment_image->ID );
						}
						$attachment_logo = hcode_wp_get_attachment_by_post_name( 'brand-logo'.$brandlogo );
						
						if( $attachment_logo ){
							update_woocommerce_term_meta( $value->term_id, 'logo_id', $attachment_logo->ID );
						}
						$brandlogo++;
					}
					hcode_log('MESSAGE - Set WooCommerce Brand Logo And Image End.');

					// Add Custom Color in pa_colors taxonomy
					hcode_log('MESSAGE - Set WooCommerce Color Attribute Start.');
					$pa_colors_exist = taxonomy_exists( 'pa_colors');
					if ( $pa_colors_exist ) {
						$attribute_colors_term = get_terms( 'pa_colors');
						$colors = array();
						
						$attribute_colors = hcode_csv_to_array(HCODE_THEME_IMPORTER_SAMPLEDATA . '/attribute_colors.csv');
						foreach ($attribute_colors as $attribute => $color) {
							$colors[] = $color['code'];
						}

						$i=0;
						foreach ($attribute_colors_term as $key => $value) {
							$empty_array = array();
							$empty_array['custom_color'] = $colors[$i];
							add_option( 'taxonomy_'.$value->term_id, $empty_array );
							$i++;
						}
					}
					hcode_log('MESSAGE - Set WooCommerce Color Attribute End.');

					// Flush rules after install
					flush_rewrite_rules();

				} else {
					// Sample Data Zip.
					$sample_data_xml = HCODE_THEME_IMPORTER_SAMPLEDATA . '/H-Code-Without-Woo.xml';
					
					// Sidebar Widgets Json File.
					$widgets_file = HCODE_THEME_IMPORTER_SAMPLEDATA . '/widget_data_without_woo.json';
					
					// Import Sample Data XML.
					$importer = new WP_Import();
					// Import Posts, Pages, Portfolio Content, Images, Menus
					$importer->fetch_attachments = true;
					ob_start();
					hcode_log('MESSAGE - H-Code-Without-Woo.xml Import Start.');
					$importer->import($sample_data_xml);
					ob_end_clean();
					hcode_log('MESSAGE - H-Code-Without-Woo.xml Import End');
				}

				// Set imported menus to registered theme locations
				// registered menu locations in theme
				$locations = get_theme_mod( 'nav_menu_locations' );
				// registered menus
				$menus = wp_get_nav_menus();
				hcode_log('MESSAGE - Import Menu Location Start.');
				// assign menus to theme locations
				if($menus) {
					foreach($menus as $menu) {
						if( $menu->name == 'Main menu' ) {
							$locations['hcodemegamenu'] = $menu->term_id;
						} else if( $menu->name == 'Footer Menu' ) {
							$locations['hcodefootermenu'] = $menu->term_id;
						}
					}
				}

				// set menus to locations
				set_theme_mod( 'nav_menu_locations', $locations );

				hcode_log('MESSAGE - Import Menu Location End.');
				// Import Theme Options
				hcode_log('MESSAGE - Import Theme Admin Option Setting Start.');
				$theme_options_txt = $theme_options_file;
				$theme_options_txt = file_get_contents( $theme_options_txt );
				$hcode_option = unserialize( base64_decode( $theme_options_txt ) );
				update_option( 'hcode_theme_setting', $hcode_option );
				hcode_log('MESSAGE - Import Theme Admin Option Setting End.');

				// Add sidebar widget areas
		        register_sidebar ( array (
	                'name' => 'Footer Social Icons"',
	                'id' => sanitize_title ( 'Footer Social Icons' ),
	                'before_widget' => '<div id="%1$s" class="custom-widget %2$s">',
	                'after_widget' => '</div>',
	                'before_title'  => '<h5 class="sidebar-title">',
	                'after_title'   => '</h5>',
	            ) );

				// Add data to widgets
				hcode_log('MESSAGE - Before Import Widget Clear All Widgetarea Start.');
				$sidebars = wp_get_sidebars_widgets();
				//$inactive = isset($sidebars['wp_inactive_widgets']) ? $sidebars['wp_inactive_widgets'] : array();

				unset($sidebars['wp_inactive_widgets']);

				foreach ( $sidebars as $sidebar => $widgets ) {
					//$inactive = array_merge($inactive, $widgets);
					$sidebars[$sidebar] = array();
				}

				$sidebars['wp_inactive_widgets'] = array();
				wp_set_sidebars_widgets( $sidebars );
				hcode_log('MESSAGE - Before Import Widget Clear All Widgetarea End.');

				if( isset( $widgets_file ) && $widgets_file ) {
					$widgets_json = $widgets_file; // widgets data file
					$widgets_json = file_get_contents( $widgets_json );
					$widget_data = $widgets_json;
					hcode_log('MESSAGE - Import Widget Setting Start.');
					$import_widgets = hcode_import_widget_sample_data( $widget_data );
				}

				// Set reading options
				hcode_log('MESSAGE - Set Static Homepage Start.');
				$homepage = get_page_by_title( $homepage_title );
				if(isset( $homepage ) && $homepage->ID) {
					update_option('show_on_front', 'page');
					update_option('page_on_front', $homepage->ID); // Front Page
					hcode_log('MESSAGE - Set Static Homepage End.');
				}else{
					hcode_log('NOTICE - Set Static Homepage Couldn\'t Be Set.');
				}
				
				// Import Revslider
				if( !class_exists('UniteFunctionsRev') ) { // if revslider is activated
					hcode_log('NOTICE - Revslider is not activated. You can import sliders manualy from /sample-data/revslider folder later.');
					return false;
				}
				if( class_exists('UniteFunctionsRev') ) { // if revslider is activated
					hcode_log('MESSAGE - Import Revslider Start.');
					
					foreach( glob( $rev_directory . '*.zip' ) as $filename ) { // get all files from revsliders data dir
						$filename = basename($filename);
						$rev_files[] = $rev_directory . $filename;
					}

					foreach( $rev_files as $rev_file ) { // finally import rev slider data files

							$filepath = $rev_file;

							//check if zip file or fallback to old, if zip, check if all files exist
							$zip = new ZipArchive;
							$importZip = $zip->open($filepath, ZIPARCHIVE::CREATE);

							if($importZip === true){ //true or integer. If integer, its not a correct zip file

								//check if files all exist in zip
								$slider_export = $zip->getStream('slider_export.txt');
								$custom_animations = $zip->getStream('custom_animations.txt');
								$dynamic_captions = $zip->getStream('dynamic-captions.css');
								$static_captions = $zip->getStream('static-captions.css');

								$content = '';
								$animations = '';
								$dynamic = '';
								$static = '';

								while (!feof($slider_export)) $content .= fread($slider_export, 1024);
								if($custom_animations){ while (!feof($custom_animations)) $animations .= fread($custom_animations, 1024); }
								if($dynamic_captions){ while (!feof($dynamic_captions)) $dynamic .= fread($dynamic_captions, 1024); }
								if($static_captions){ while (!feof($static_captions)) $static .= fread($static_captions, 1024); }

								fclose($slider_export);
								if($custom_animations){ fclose($custom_animations); }
								if($dynamic_captions){ fclose($dynamic_captions); }
								if($static_captions){ fclose($static_captions); }

								//check for images!

							}else{ //check if fallback
								//get content array
								$content = @file_get_contents($filepath);
							}

							if($importZip === true){ //we have a zip
								$db = new UniteDBRev();

								//update/insert custom animations
								$animations = @unserialize($animations);
								if(!empty($animations)){
									foreach($animations as $key => $animation){ //$animation['id'], $animation['handle'], $animation['params']
										$exist = $db->fetch(GlobalsRevSlider::$table_layer_anims, "handle = '".$animation['handle']."'");
										if(!empty($exist)){ //update the animation, get the ID
											if($updateAnim == "true"){ //overwrite animation if exists
												$arrUpdate = array();
												$arrUpdate['params'] = stripslashes(json_encode(str_replace("'", '"', $animation['params'])));
												$db->update(GlobalsRevSlider::$table_layer_anims, $arrUpdate, array('handle' => $animation['handle']));

												$id = $exist['0']['id'];
											}else{ //insert with new handle
												$arrInsert = array();
												$arrInsert["handle"] = 'copy_'.$animation['handle'];
												$arrInsert["params"] = stripslashes(json_encode(str_replace("'", '"', $animation['params'])));

												$id = $db->insert(GlobalsRevSlider::$table_layer_anims, $arrInsert);
											}
										}else{ //insert the animation, get the ID
											$arrInsert = array();
											$arrInsert["handle"] = $animation['handle'];
											$arrInsert["params"] = stripslashes(json_encode(str_replace("'", '"', $animation['params'])));

											$id = $db->insert(GlobalsRevSlider::$table_layer_anims, $arrInsert);
										}

										//and set the current customin-oldID and customout-oldID in slider params to new ID from $id
										$content = str_replace(array('customin-'.$animation['id'], 'customout-'.$animation['id']), array('customin-'.$id, 'customout-'.$id), $content);
									}
								}else{
								}

								//overwrite/append static-captions.css
								if(!empty($static)){
									if(isset( $updateStatic ) && $updateStatic == "true"){ //overwrite file
										RevOperations::updateStaticCss($static);
									}else{ //append
										$static_cur = RevOperations::getStaticCss();
										$static = $static_cur."\n".$static;
										RevOperations::updateStaticCss($static);
									}
								}
								//overwrite/create dynamic-captions.css
								//parse css to classes
								$dynamicCss = UniteCssParserRev::parseCssToArray($dynamic);

								if(is_array($dynamicCss) && $dynamicCss !== false && count($dynamicCss) > 0){
									foreach($dynamicCss as $class => $styles){
										//check if static style or dynamic style
										$class = trim($class);

										if((strpos($class, ':hover') === false && strpos($class, ':') !== false) || //before, after
											strpos($class," ") !== false || // .tp-caption.imageclass img or .tp-caption .imageclass or .tp-caption.imageclass .img
											strpos($class,".tp-caption") === false || // everything that is not tp-caption
											(strpos($class,".") === false || strpos($class,"#") !== false) || // no class -> #ID or img
											strpos($class,">") !== false){ //.tp-caption>.imageclass or .tp-caption.imageclass>img or .tp-caption.imageclass .img
											continue;
										}

										//is a dynamic style
										if(strpos($class, ':hover') !== false){
											$class = trim(str_replace(':hover', '', $class));
											$arrInsert = array();
											$arrInsert["hover"] = json_encode($styles);
											$arrInsert["settings"] = json_encode(array('hover' => 'true'));
										}else{
											$arrInsert = array();
											$arrInsert["params"] = json_encode($styles);
										}
										//check if class exists
										$result = $db->fetch(GlobalsRevSlider::$table_css, "handle = '".$class."'");

										if(!empty($result)){ //update
											$db->update(GlobalsRevSlider::$table_css, $arrInsert, array('handle' => $class));
										}else{ //insert
											$arrInsert["handle"] = $class;
											$db->insert(GlobalsRevSlider::$table_css, $arrInsert);
										}
									}
								}else{
								}
							}

							$content = preg_replace('!s:(\d+):"(.*?)";!e', "'s:'.strlen('$2').':\"$2\";'", $content); //clear errors in string

							$arrSlider = @unserialize($content);
							$sliderParams = $arrSlider["params"];

							if(isset($sliderParams["background_image"]))
								$sliderParams["background_image"] = UniteFunctionsWPRev::getImageUrlFromPath($sliderParams["background_image"]);

							$json_params = json_encode($sliderParams);

							//new slider
							$arrInsert = array();
							$arrInsert["params"] = $json_params;
							$arrInsert["title"] = UniteFunctionsRev::getVal($sliderParams, "title","Slider1");
							$arrInsert["alias"] = UniteFunctionsRev::getVal($sliderParams, "alias","slider1");
							$sliderID = $wpdb->insert(GlobalsRevSlider::$table_sliders,$arrInsert);
							$sliderID = $wpdb->insert_id;

							//-------- Slides Handle -----------

							//create all slides
							$arrSlides = $arrSlider["slides"];

							$alreadyImported = array();

							foreach($arrSlides as $slide){

								$params = $slide["params"];
								$layers = $slide["layers"];

								//convert params images:
								if(isset($params["image"])){
									//import if exists in zip folder
									if(trim($params["image"]) !== ''){
										if($importZip === true){ //we have a zip, check if exists
											$image = $zip->getStream('images/'.$params["image"]);
											if(!$image){
												echo $params["image"].' not found!<br>';
											}else{
												if(!isset($alreadyImported['zip://'.$filepath."#".'images/'.$params["image"]])){
													$importImage = UniteFunctionsWPRev::import_media('zip://'.$filepath."#".'images/'.$params["image"], $sliderParams["alias"].'/');

													if($importImage !== false){
														$alreadyImported['zip://'.$filepath."#".'images/'.$params["image"]] = $importImage['path'];

														$params["image"] = $importImage['path'];
													}
												}else{
													$params["image"] = $alreadyImported['zip://'.$filepath."#".'images/'.$params["image"]];
												}
											}
										}
									}
									$params["image"] = UniteFunctionsWPRev::getImageUrlFromPath($params["image"]);
								}

								//convert layers images:
								foreach($layers as $key=>$layer){
									if(isset($layer["image_url"])){
										//import if exists in zip folder
										if(trim($layer["image_url"]) !== ''){
											if($importZip === true){ //we have a zip, check if exists
												$image_url = $zip->getStream('images/'.$layer["image_url"]);
												if(!$image_url){
													echo $layer["image_url"].' not found!<br>';
												}else{
													if(!isset($alreadyImported['zip://'.$filepath."#".'images/'.$layer["image_url"]])){
														$importImage = UniteFunctionsWPRev::import_media('zip://'.$filepath."#".'images/'.$layer["image_url"], $sliderParams["alias"].'/');

														if($importImage !== false){
															$alreadyImported['zip://'.$filepath."#".'images/'.$layer["image_url"]] = $importImage['path'];

															$layer["image_url"] = $importImage['path'];
														}
													}else{
														$layer["image_url"] = $alreadyImported['zip://'.$filepath."#".'images/'.$layer["image_url"]];
													}
												}
											}
										}
										$layer["image_url"] = UniteFunctionsWPRev::getImageUrlFromPath($layer["image_url"]);
										$layers[$key] = $layer;
									}
								}

								//create new slide
								$arrCreate = array();
								$arrCreate["slider_id"] = $sliderID;
								$arrCreate["slide_order"] = $slide["slide_order"];
								$arrCreate["layers"] = json_encode($layers);
								$arrCreate["params"] = json_encode($params);

								$wpdb->insert(GlobalsRevSlider::$table_slides,$arrCreate);
							//}
						}
					}
					hcode_log('MESSAGE - Import Revslider End.');
				}

				exit;
			}else{
				hcode_log('ERROR - Importer can\'t load WP_Importer or WP_Import class not exists');
				return false;
			}

		}
	}
endif;

if( ! ( function_exists( 'hcode_wp_get_attachment_by_post_name' ) ) ):
    function hcode_wp_get_attachment_by_post_name( $post_name ) {
        $args = array(
            'post_per_page' => 1,
            'post_type'     => 'attachment',
            'name'          => trim ( $post_name ),
        );
        $get_posts = new Wp_Query( $args );

        if ( $get_posts->posts[0] )
            return $get_posts->posts[0];
        else
          return false;
    }
endif;

// For More Info Check Widget Import Plugin ( http://wordpress.org/plugins/widget-settings-importexport/ )
if( ! ( function_exists( 'hcode_import_widget_sample_data' ) ) ):
	function hcode_import_widget_sample_data( $widget_data ) {
		$json_data = $widget_data;
		$json_data = json_decode( $json_data, true );

		$sidebar_data = $json_data[0];
		$widget_data = $json_data[1];

		foreach ( $widget_data as $widget_data_title => $widget_data_value ) {
			$widgets[ $widget_data_title ] = '';
			foreach( $widget_data_value as $widget_data_key => $widget_data_array ) {
				if( is_int( $widget_data_key ) ) {
					$widgets[$widget_data_title][$widget_data_key] = 'on';
				}
			}
		}
		unset($widgets[""]);

		foreach ( $sidebar_data as $title => $sidebar ) {
			$count = count( $sidebar );
			for ( $i = 0; $i < $count; $i++ ) {
				$widget = array( );
				$widget['type'] = trim( substr( $sidebar[$i], 0, strrpos( $sidebar[$i], '-' ) ) );
				$widget['type-index'] = trim( substr( $sidebar[$i], strrpos( $sidebar[$i], '-' ) + 1 ) );
				if ( !isset( $widgets[$widget['type']][$widget['type-index']] ) ) {
					unset( $sidebar_data[$title][$i] );
				}
			}
			$sidebar_data[$title] = array_values( $sidebar_data[$title] );
		}

		foreach ( $widgets as $widget_title => $widget_value ) {
			foreach ( $widget_value as $widget_key => $widget_value ) {
				$widgets[$widget_title][$widget_key] = $widget_data[$widget_title][$widget_key];
			}
		}

		$sidebar_data = array( array_filter( $sidebar_data ), $widgets );

		hcode_parse_import_widget_sample_data( $sidebar_data );
	}
endif;

if( ! ( function_exists( 'hcode_parse_import_widget_sample_data' ) ) ):
	function hcode_parse_import_widget_sample_data( $import_array ) {
		global $wp_registered_sidebars;
		$sidebars_data = $import_array[0];
		$widget_data = $import_array[1];
		$current_sidebars = get_option( 'sidebars_widgets' );
		$new_widgets = array( );

		foreach ( $sidebars_data as $import_sidebar => $import_widgets ) :

			foreach ( $import_widgets as $import_widget ) :
				//if the sidebar exists
				if ( isset( $wp_registered_sidebars[$import_sidebar] ) ) :
					$title = trim( substr( $import_widget, 0, strrpos( $import_widget, '-' ) ) );
					$index = trim( substr( $import_widget, strrpos( $import_widget, '-' ) + 1 ) );
					$current_widget_data = get_option( 'widget_' . $title );
					$new_widget_name = hcode_get_new_widget_name( $title, $index );
					$new_index = trim( substr( $new_widget_name, strrpos( $new_widget_name, '-' ) + 1 ) );

					if ( !empty( $new_widgets[ $title ] ) && is_array( $new_widgets[$title] ) ) {
						while ( array_key_exists( $new_index, $new_widgets[$title] ) ) {
							$new_index++;
						}
					}
					$current_sidebars[$import_sidebar][] = $title . '-' . $new_index;
					if ( array_key_exists( $title, $new_widgets ) ) {
						$new_widgets[$title][$new_index] = $widget_data[$title][$index];
						$multiwidget = $new_widgets[$title]['_multiwidget'];
						unset( $new_widgets[$title]['_multiwidget'] );
						$new_widgets[$title]['_multiwidget'] = $multiwidget;
					} else {
						$current_widget_data[$new_index] = $widget_data[$title][$index];
						$current_multiwidget = isset($current_widget_data['_multiwidget']) ? $current_widget_data['_multiwidget'] : false;
						$new_multiwidget = isset($widget_data[$title]['_multiwidget']) ? $widget_data[$title]['_multiwidget'] : false;
						$multiwidget = ($current_multiwidget != $new_multiwidget) ? $current_multiwidget : 1;
						unset( $current_widget_data['_multiwidget'] );
						$current_widget_data['_multiwidget'] = $multiwidget;
						$new_widgets[$title] = $current_widget_data;
					}

				endif;
			endforeach;
		endforeach;

		if ( isset( $new_widgets ) && isset( $current_sidebars ) ) {
			update_option( 'sidebars_widgets', $current_sidebars );

			foreach ( $new_widgets as $title => $content ){
				update_option( 'widget_' . $title, $content );
			}
			hcode_log('MESSAGE - Import Widget Setting End.');
			return true;
		}
		hcode_log('NOTICE - Import Widget Setting Not Completed.');
		return false;
	}
endif;

if( ! ( function_exists( 'hcode_get_new_widget_name' ) ) ):
	function hcode_get_new_widget_name( $widget_name, $widget_index ) {
		$current_sidebars = get_option( 'sidebars_widgets' );
		$all_widget_array = array( );
		foreach ( $current_sidebars as $sidebar => $widgets ) {
			if ( !empty( $widgets ) && is_array( $widgets ) && $sidebar != 'wp_inactive_widgets' ) {
				foreach ( $widgets as $widget ) {
					$all_widget_array[] = $widget;
				}
			}
		}
		while ( in_array( $widget_name . '-' . $widget_index, $all_widget_array ) ) {
			$widget_index++;
		}
		$new_widget_name = $widget_name . '-' . $widget_index;
		return $new_widget_name;
	}
endif;

// Function To Add Hcode Log.
if( ! ( function_exists( 'hcode_log' ) ) ):
	function hcode_log($message, $append = true) {
		$upload_dir = wp_upload_dir();
		if (isset($upload_dir['baseurl'])) {
			
			$data = '';
			if (!empty($message)) {
				$data = "<p>".date("Y-m-d H:i:s").' - '.$message."</p>";
			}
			
			if ($append === true) {
				file_put_contents($upload_dir['basedir'].'/importer.log', $data, FILE_APPEND);
			} else {
				file_put_contents($upload_dir['basedir'].'/importer.log', $data);
			}
		}
	}
endif;

// Function To Get Hcode Log.
if( ! ( function_exists( 'get_hcode_log' ) ) ):
	function get_hcode_log() {
		$upload_dir = wp_upload_dir();
		if (isset($upload_dir['baseurl'])) {
			
			if (file_exists($upload_dir['basedir'].'/importer.log')) {
				return file_get_contents($upload_dir['basedir'].'/importer.log');
			}
		}
		return '';
	}
endif;
// Ajax Function To Check Refresh Import Logs.
if( ! ( function_exists( 'hcode_refresh_import_log' ) ) ):
	function hcode_refresh_import_log() {
		
		$checkhcodelog = get_hcode_log();
		//don't add message if ERROR was found, JS script is going to stop refreshing
		if (strpos($checkhcodelog,'ERROR') === false) { 
			hcode_log('MESSAGE - Import in progress...');
		}
		$printlog = get_hcode_log();
		echo $printlog;
		die();
	}
endif;

/* To Read WooCommerce Product Attribute Colors */
if( ! ( function_exists( 'hcode_csv_to_array' ) ) ):
	function hcode_csv_to_array($filename='', $delimiter=',')
	{
		if(!file_exists($filename) || !is_readable($filename))
			return FALSE;
		
		$header = NULL;
		$data = array();
		if (($handle = fopen($filename, 'r')) !== FALSE)
		{
			while (($row = fgetcsv($handle, 1000, $delimiter)) !== FALSE)
			{
				if(!$header)
					$header = $row;
				else
					$data[] = array_combine($header, $row);
			}
			fclose($handle);
		}
		return $data;
	}
endif;