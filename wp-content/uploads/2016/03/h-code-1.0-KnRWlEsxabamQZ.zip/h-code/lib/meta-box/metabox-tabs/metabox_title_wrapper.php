<?php
/**
 * Metabox For Title Wrapper.
 *
 * @package H-Code
 */
?>
<?php
hcode_meta_box_dropdown('hcode_enable_title_wrapper_single',
				esc_html__('Enable Title', 'H-Code'),
				array('1' => esc_html__('Default', 'H-Code'),
					  '2' => esc_html__('Yes', 'H-Code'),
					  '0' => esc_html__('No', 'H-Code')
					 ),
				esc_html__('If on, a title will display in page', 'H-Code')
			);
hcode_meta_box_dropdown( 'hcode_page_title_premade_style_single',
				esc_html__('Title Template Style', 'H-Code'),
					array(
                           esc_html__('title-white', 'H-Code') => 'Title White',
                           esc_html__('title-gray', 'H-Code') => 'Title Gray',
                           esc_html__('title-dark-gray', 'H-Code') => 'Title Dark Gray',
                           esc_html__('title-black', 'H-Code') => 'Title Black',
                           esc_html__('title-with-image', 'H-Code') => 'Title With Image',
                           esc_html__('title-large', 'H-Code') => 'Title Large',
                           esc_html__('title-large-without-overlay', 'H-Code') => 'Title Large Without Overlay',
                           esc_html__('title-small-white', 'H-Code') => 'Title Small White',
                           esc_html__('title-small-gray', 'H-Code') => 'Title Small Gray',
                           esc_html__('title-small-dark-gray', 'H-Code') => 'Title Small Dark Gray',
                           esc_html__('title-small-black', 'H-Code') => 'Title Small Black',
                           esc_html__('title-center-align', 'H-Code') => 'Title Center Align',
                          ),
				esc_html__('Choose template style for the title', 'H-Code')
			);
hcode_meta_box_text('hcode_header_subtitle_single',
				esc_html__('Subtitle', 'H-Code')
			);
hcode_meta_box_upload(	'hcode_title_background_single', 
				esc_html__('Title Background Image', 'H-Code'),
				esc_html__('Recommended image size (1920px X 700px) for better result.', 'H-Code')
			);
hcode_meta_box_dropdown( 'hcode_title_parallax_effect_single',
				esc_html__('Parallax effect', 'H-Code'),
				array('no-effect' => esc_html__('No Effect', 'H-Code'),
					  'parallax1' => esc_html__('parallax-effect-1', 'H-Code'),
					  'parallax2' => esc_html__('parallax-effect-2', 'H-Code'),
					  'parallax3' => esc_html__('parallax-effect-3', 'H-Code'),
					  'parallax4' => esc_html__('parallax-effect-4', 'H-Code'),
					  'parallax5' => esc_html__('parallax-effect-5', 'H-Code'),
					  'parallax6' => esc_html__('parallax-effect-6', 'H-Code'),
					  'parallax7' => esc_html__('parallax-effect-7', 'H-Code'),
					  'parallax8' => esc_html__('parallax-effect-8', 'H-Code'),
					  'parallax9' => esc_html__('parallax-effect-9', 'H-Code'),
					  'parallax10' => esc_html__('parallax-effect-10', 'H-Code'),
					  'parallax11' => esc_html__('parallax-effect-11', 'H-Code'),
					  'parallax12' => esc_html__('parallax-effect-12', 'H-Code')
					 ),
				esc_html__('Choose parallax effect', 'H-Code')
			);
hcode_meta_box_dropdown(	'hcode_page_title_show_breadcrumb_single',
				esc_html__('Enable Breadcrumb', 'H-Code'),
				array(
					  '1' => esc_html__('Yes', 'H-Code'),
					  '0' => esc_html__('No', 'H-Code')
					 ),
				esc_html__('If on, breadcrumb will display in title section', 'H-Code')
			);
hcode_meta_box_dropdown(	'hcode_page_title_show_separator_single',
				esc_html__('Enable Separator', 'H-Code'),
				array(
					  '1' => esc_html__('Yes', 'H-Code'),
					  '0' => esc_html__('No', 'H-Code')
					 ),
				esc_html__('If on, separator will display in title section', 'H-Code')
			);
?>