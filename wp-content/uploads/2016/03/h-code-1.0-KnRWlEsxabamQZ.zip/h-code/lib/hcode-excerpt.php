<?php
/**
 * Excerpt Class.
 *
 * @package H-Code
 */
?>
<?php
/**
 * Exerpt length
 * 
 * @package framework
 * @since framework 1.0
 */
if(!class_exists('hcode_Excerpt')){
  class hcode_Excerpt {

    public static $length = 50;


    /**
     * Sets the length for the excerpt,
     *
     * @param string $new_length 
     * @return void
     */
    public static function hcode_length($new_length = 55) {
      hcode_Excerpt::$length = $new_length;
      add_filter('excerpt_length', 'hcode_Excerpt::hcode_new_length');
    }
    
    /**
     * Sets the length for the excerpt 
     *
     * @param string $new_length 
     * @return void
     */
    public static function hcode_get_by_length($new_length = 55) {
      hcode_Excerpt::$length = $new_length;
      add_filter('excerpt_length', 'hcode_Excerpt::hcode_new_length');
      add_filter('excerpt_more', 'hcode_Excerpt::hcode_new_excerpt_more');

      return hcode_Excerpt::hcode_get();
    }

    public static function hcode_new_length() {
        return hcode_Excerpt::$length;
    }
    
    public static function hcode_get() {
      return apply_filters( 'the_excerpt', get_the_excerpt() );
    }

    public static function hcode_new_excerpt_more( $more ) {
      return '...';
    }
  }
}