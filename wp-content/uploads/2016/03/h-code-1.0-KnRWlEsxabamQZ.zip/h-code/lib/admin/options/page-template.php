<?php
/**
 * Page or Template Tab For Theme Option.
 *
 * @package H-Code
 */
?>
<?php
$this->sections[] = array(
    'icon' => 'fa fa-file-text-o',
    'title' => esc_html__('Page/Template', 'H-Code'),
    'fields' => array(
        
        /*  Under Construction */
        array(
            'id'        => 'opt-accordion-begin-under-construction',
            'type'      => 'accordion',
            'title'     => esc_html__('Under Construction Page', 'H-Code'),
            'subtitle'  => esc_html__('Select page to display when site is in under construction mode', 'H-Code'),
            'position'  => 'start',
        ),
        array(
            'id'=>'under_construction_page',
            'type' => 'select',
            'title' => esc_html__('Under Construction Page', 'H-Code'),
            'data' => 'pages'
        ),
        array(
            'id'        => 'opt-accordion-end-under-construction',
            'type'      => 'accordion',
            'position'  => 'end'
        ),

        /*  Comment */
        array(
            'id'        => 'opt-accordion-begin-general',
            'type'      => 'accordion',
            'title'     => esc_html__('Comments Settings', 'H-Code'),
            'subtitle'  => esc_html__('Enable/Disable comments in post or portfolio page', 'H-Code'),
            'position'  => 'start',
        ),
        array(
            'id'=>'hcode_enable_page_comment',
            'type' => 'switch', 
            'title' => esc_html__('Enable Comments in Page', 'H-Code'),
            'default'  => true,
        ),
        array(
            'id'=>'hcode_enable_post_comment',
            'type' => 'switch', 
            'title' => esc_html__('Enable Comments in Post', 'H-Code'),
            'default' => false,
        ),
        array(
            'id'=>'hcode_enable_portfolio_comment',
            'type' => 'switch', 
            'title' => esc_html__('Enable Comments in Portfolio', 'H-Code'),
            'default' => false,
        ),
        array(
            'id'        => 'opt-accordion-end-general',
            'type'      => 'accordion',
            'position'  => 'end'
        ),

        /*  404 Page */
        array(
            'id'        => 'opt-accordion-begin-general',
            'type'      => 'accordion',
            'title'     => esc_html__('404 Page Settings', 'H-Code'),
            'subtitle'  => esc_html__('Set title, content, image, button text and button URL for 404 / page not found page', 'H-Code'),
            'position'  => 'start',
        ),
        array(
            'id'       => '404_enable_header',
            'type'     => 'switch',
            'title'    => esc_html__('Enable Header', 'H-Code'),
            'default'  => true,
            '1'       => 'On',
            '0'      => 'Off',
          ),
        array(
            'id'       => '404_header_type',
            'type'     => 'images',
            'title'    => esc_html__('Select a Header Style', 'H-Code'),
            'options' => array(
                "headertype1" => get_template_directory_uri()."/assets/images/header1.jpg",
                "headertype2" => get_template_directory_uri()."/assets/images/header2.jpg",
                "headertype3" => get_template_directory_uri()."/assets/images/header3.jpg",
                "headertype4" => get_template_directory_uri()."/assets/images/header4.jpg",
                "headertype5" => get_template_directory_uri()."/assets/images/header5.jpg",
                "headertype6" => get_template_directory_uri()."/assets/images/header6.jpg",
                "headertype7" => get_template_directory_uri()."/assets/images/header7.jpg",
                "headertype8" => get_template_directory_uri()."/assets/images/header6.jpg",
            ),
            'imgtitle' => array(
                "imgtitle1" => "Light Header",
                "imgtitle2" => "Dark Header",
                "imgtitle3" => "Dark Transparent Header",
                "imgtitle4" => "Light Transparent Header",
                "imgtitle5" => "Static Sticky Header",
                "imgtitle6" => "White Sticky Header",
                "imgtitle7" => "Gray Header",
                "imgtitle8" => "Non Sticky Header",
            ),
            'default' => 'headertype1',
            'validate'  => 'not_empty'
        ),
        array(
            'id'       => '404_header_text_color',
            'type'     => 'select',
            'title'    => esc_html__('Header Text Color', 'H-Code'),
            'options' => array(
                'nav-black' => esc_html__('Black', 'H-Code'),
                'nav-white' => esc_html__('White', 'H-Code'),
            ),
            'default' => 'nav-black',
          ),
        array(
            'id' => '404_logo_setting',
            'type' => 'info_title',
            'title' => esc_html__('Logo Settings', 'H-Code'),
        ),
        array(
            'id'       => '404_header_logo',
            'type'     => 'media',
            'preview'  => true,
            'url'      => true,  
            'title'    => esc_html__( 'Logo', 'H-Code' ),
            'subtitle' => esc_html__( 'Upload the logo that will be displayed in the header', 'H-Code' ),
        ),
        array(
            'id'       => '404_header_light_logo',
            'type'     => 'media',
            'preview'  => true,
            'url'      => true,  
            'title'    => esc_html__( 'Logo (Light)', 'H-Code' ),
            'subtitle' => esc_html__( 'Upload a light version of logo used in dark backgrounds header template', 'H-Code' ),
        ),
        array(
            'id'       => '404_retina_logo',
            'type'     => 'media',
            'preview'  => true,
            'url'      => true,  
            'title'    => esc_html__( 'Logo Retina', 'H-Code' ),
            'subtitle' => esc_html__( 'Optional retina version displayed in devices with retina display (high resolution display).', 'H-Code' ),
        ),
        array(
            'id'       => '404_retina_logo_light',
            'type'     => 'media',
            'preview'  => true,
            'url'      => true,  
            'title'    => esc_html__( 'Logo Retina (Light)', 'H-Code' ),
            'subtitle' => esc_html__( '(Upload a light version of logo) optional retina version displayed in devices with retina display (high resolution display).', 'H-Code' ),
        ),
        array(
              'id' => '404_retina_logo_width',
              'type' => 'text',
              'title' => esc_html__('Retina logo Width', 'H-Code'),
              'default' => '',
              'subtitle' => esc_html__('Specify the width in pixel eg. 15px', 'H-Code'),
        ),
        array(
              'id' => '404_retina_logo_height',
              'type' => 'text',
              'title' => esc_html__('Retina logo Height', 'H-Code'),
              'default' => '',
              'subtitle' => esc_html__('Specify the height in pixel eg. 15px', 'H-Code'),
        ),
        array(
            'id' => '404_module_setting',
            'type' => 'info_title',
            'title' => esc_html__('Modules Settings', 'H-Code'),
        ),
        array(
            'id'       => '404_header_search',
            'type'     => 'switch',
            'title'    => esc_html__('Search Modules', 'H-Code'),
            'default'  => false,
            'subtitle' => esc_html__('If on, a search module will be displayed in header section', 'H-Code'),
            '1'       => 'On',
            '0'      => 'Off',
        ), 
        array(
            'id'       => '404_header_cart',
            'type'     => 'switch',
            'title'    => esc_html__('Cart Module', 'H-Code'),
            'default'  => false,
            'subtitle' => esc_html__('If on, a cart module will be displayed in header section. It will only work if WooCommerce plugin is installed and active.', 'H-Code'),
            '1'       => 'On',
            '0'      => 'Off',
        ),
        array(
            'id'       => '404_title_text',
            'type'     => 'text',
            'title'    => esc_html__( 'Title Text', 'H-Code' ),
        ),
        array(
            'id'       => '404_content_text',
            'type'     => 'textarea',
            'title'    => esc_html__( '404 Content Text', 'H-Code' ),
        ),
        array(
            'id'       => '404_image',
            'type'     => 'media',
            'preview'  => true,
            'url'      => true,  
            'title'    => esc_html__( '404 image', 'H-Code' ),
            'subtitle' => esc_html__( 'Upload image', 'H-Code' ),
        ),
        array(
            'id'       => '404_button',
            'type'     => 'text',
            'title'    => esc_html__( 'Button Text', 'H-Code' ),
        ),
        array(
            'id'=>'404_button_url',
            'type' => 'select',
            'title' => esc_html__('Button Url', 'H-Code'),
            'data' => 'pages'
        ),
        array(
            'id'        => 'opt-accordion-end-general',
            'type'      => 'accordion',
            'position'  => 'end'
        ),
    )
);
?>