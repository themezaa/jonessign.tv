<?php
/**
 * Show options for ordering
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>
<form class="woocommerce-ordering" method="get">
<div class="col-lg-3 col-md-4 col-sm-12 pull-right sm-text-center select-order-box">
    <div class="select-style input-round med-input shop-shorting no-border">                            
		<?php /*<select name="orderby" class="orderby">
			<?php foreach ( $catalog_orderby_options as $id => $name ) : ?>
				<option value="<?php echo esc_attr( $id ); ?>" <?php selected( $orderby, $id ); ?>><?php echo esc_html( $name ); ?></option>
			<?php endforeach; ?>
		</select><?php */ ?>
		<select name="orderby" class="orderby">
        <?php
	      $catalog_orderby = apply_filters( 'woocommerce_catalog_orderby', array(
	        'menu_order' => esc_html__( 'Default sorting', 'woocommerce' ),
	        'popularity' => esc_html__( 'by popularity', 'woocommerce' ),
	        'rating'     => esc_html__( 'by average rating', 'woocommerce' ),
	        'date'       => esc_html__( 'by newness', 'woocommerce' ),
	        'price'      => esc_html__( 'by price: low to high', 'woocommerce' ),
	        'price-desc' => esc_html__( 'by price: high to low', 'woocommerce' )
	      ) );

	      if ( get_option( 'woocommerce_enable_review_rating' ) === 'no' )
	        unset( $catalog_orderby['rating'] );

	      foreach ( $catalog_orderby as $id => $name )
	        echo '<option value="' . esc_attr( $id ) . '" ' . selected( $orderby, $id, false ) . '>' . esc_attr( $name ) . '</option>';
	    ?>
    </select>
	</div>
	<?php
		// Keep query string vars intact
		foreach ( $_GET as $key => $val ) {
			if ( 'orderby' === $key || 'submit' === $key ) {
				continue;
			}
			if ( is_array( $val ) ) {
				foreach( $val as $innerVal ) {
					echo '<input type="hidden" name="' . esc_attr( $key ) . '[]" value="' . esc_attr( $innerVal ) . '" />';
				}
			} else {
				echo '<input type="hidden" name="' . esc_attr( $key ) . '" value="' . esc_attr( $val ) . '" />';
			}
		}
	?>
</div>
</form>
