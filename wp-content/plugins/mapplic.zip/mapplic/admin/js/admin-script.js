jQuery(document).ready(function($) {
	$('.sortable-list').sortable({
		placeholder: 'list-item-placeholder',
		forcePlaceholderSize: true,
		handle: '.list-item-handle'
	});

	$(document).on('keyup', '.title-input', function(event) {
		var text = $(this).val();
		if (text === '') text = 'undefined';

		$(this).closest('.list-item').find('.menu-item-title').text(text);
	});

	$(document).on('click', '.menu-item-toggle', function(event) {
		event.preventDefault();
		$(this).closest('.list-item').children('.list-item-settings').slideToggle(200);
		$(this).toggleClass('opened');
	});

	$('.color-picker').wpColorPicker();

	// Media buttons
	$(document).on('click', '.media-button', function(event) {
		var button = this;

		var media_popup = wp.media({
			title: 'Select or Upload File',
			button: {
				text: 'Select'
			},
			multiple: false,
		});

		media_popup.on('select', function() {
			var attachment = media_popup.state().get('selection').first().toJSON();

			$(button).closest('div').find('.input-text').val(attachment.url);

			//$(button).siblings('.input-text').val(attachment.url);
		}).open();
	});

	// Item actions
	$(document).on('click', '.item-cancel', function(event) {
		event.preventDefault();
		$(this).closest('.list-item-settings').slideToggle(200);
	});

	$(document).on('click', '.item-delete', function(event) {
		event.preventDefault();
		if (confirm('Are you sure you want to delete the selected item?')) {
			$(this).closest('.list-item').remove();
		}
	});

	// Categories
	$('#new-category').click(function() {
		$('#category-list .new-item').clone().removeClass('new-item').appendTo('#category-list');
	});

	// Floors
	$('#new-floor').click(function() {
		$('#floor-list .new-item').clone().removeClass('new-item').appendTo('#floor-list');
	});

	// New landmark
	$('#new-landmark').click(function() {
		// Remove selection if any
		$('.selected-pin').removeClass('selected-pin');
		// Show the cleared landmark fields
		$('#landmark-settings').show();
		$('#landmark-settings input[type="text"]').val('');
		tinyMCE.activeEditor.setContent('');
		$('#landmark-settings .fill-input').val('');
		$('#landmark-settings .link-input').val('');
		$('#landmark-settings .category-select').val('false');
		$('#landmark-settings .thumbnail-input').val('');
		$('#landmark-settings .action-select').val('tooltip');
		$('#landmark-settings .zoom-input').val('');
		// Change button text
		$('#save-landmark').val('Add');		
	});

	$('#pins-input .mapplic-pin').click(function() {
		$('#pins-input .selected').removeClass('selected');
		$(this).addClass('selected');

		var selected = $('.selected-pin');
		if (selected.length) {

			var data = selected.data('landmarkData'),
				pin = $(this).data('pin');

			selected.attr('class', 'mapplic-pin selected-pin ' + pin);
			data.pin = pin;
		}
	});

	$('#save-landmark').click(function() {
		var data = null,
			selected = $('.selected-pin');
		
		if (selected.length) {
			data = $('.selected-pin').data('landmarkData');
		}
		else {
			data = {};
			data.id = $('#landmark-settings .id-input').val();
			data.title = $('#landmark-settings .title-input').val();
			if ($('#wp-descriptioninput-wrap').hasClass('html-active')) {
				data.description = $('#descriptioninput').val();
			}
			else {
				data.description = tinyMCE.activeEditor.getContent();
			}
			data.fill = $('#landmark-settings .fill-input').val();
			data.link = $('#landmark-settings .link-input').val();
			data.category = $('#landmark-settings .category-select').val();
			data.action = $('#landmark-settings .action-select').val();
			data.pin = $('#pins-input .mapplic-pin.selected').data('pin');
			data.thumbnail = $('#landmark-settings .thumbnail-input').val();
			data.zoom = $('#landmark-settings .zoom-input').val();
			data.x = 0.5;
			data.y = 0.5;
			$(this).val('Save');

			$.each(mapData.levels, function(index, value) {
				if (value.id == shownLevel) {
					value.locations.push(data);
				}
			});

			var pin = $('<a></a>').attr({'href': '#' + data.id, 'title': data.title}).addClass('mapplic-pin selected-pin').addClass(data.pin).css({'top': '50%', 'left': '50%'}).click(function(e) {
				e.preventDefault();
			}).appendTo($('.mapplic-layer:visible'));
			pin.data('landmarkData', data);
		}

		data.id = $('#landmark-settings .id-input').val();
		data.title = $('#landmark-settings .title-input').val();
		if ($('#wp-descriptioninput-wrap').hasClass('html-active')) data.description = $('#descriptioninput').val();
		else data.description = tinyMCE.activeEditor.getContent();
		data.fill = $('#landmark-settings .fill-input').val();
		data.link = $('#landmark-settings .link-input').val();
		data.category = $('#landmark-settings .category-select').val();
		data.action = $('#landmark-settings .action-select').val();
		data.thumbnail = $('#landmark-settings .thumbnail-input').val();
		data.pin = $('#pins-input .mapplic-pin.selected').data('pin');
		data.zoom = $('#landmark-settings .zoom-input').val();
	});

	$('#delete-landmark').click(function() {
		var data = $('.selected-pin').data('landmarkData');

		// Remove the location and pin
		if (data) {
			data.id = null;
			$('.selected-pin').remove();
		}

		// Hide the settings
		$('#landmark-settings').hide();
	});

	var getParameter = function(param) {
		var pageURL = window.location.search.substring(1);
		var variables = pageURL.split('&');
		for (var i = 0; i < variables.length; i++) {
			var paramName = variables[i].split('=');
			if (paramName[0] == param) {
				return paramName[1];
			}
		}
	}

	// Load the map
	$('#admin-map').mapplic({
		id: getParameter('map'),
		height: 420,
		locations: true,
		sidebar: false,
		search: true,
		minimap: true,
		slide: 0
	});

	var invalid;
	var errormsg;

	// Form submit
	$('.form-submit').click(function(event) {
		invalid = false;

		var newData = {};

		if (typeof mapData === 'undefined') mapData = {};
		else newData = mapData;

		newData['mapwidth'] = $('#setting-mapwidth').val();
		newData['mapheight'] = $('#setting-mapheight').val();

		if ($('#setting-minimap').is(':checked')) newData['minimap'] = 'true';
		else newData['minimap'] = false;

		if ($('#setting-zoombuttons').is(':checked')) newData['zoombuttons'] = 'true';
		else newData['zoombuttons'] = false;

		if ($('#setting-sidebar').is(':checked')) newData['sidebar'] = 'true';
		else newData['sidebar'] = false;

		if ($('#setting-search').is(':checked')) newData['search'] = 'true';
		else newData['search'] = false;

		if ($('#setting-hovertip').is(':checked')) newData['hovertip'] = 'true';
		else newData['hovertip'] = false;

		if ($('#setting-fullscreen').is(':checked')) newData['fullscreen'] = 'true';
		else newData['fullscreen'] = false;

		var zoomlimit = $('#setting-zoomlimit').val();
		if (isNaN(zoomlimit) || zoomlimit == '') newData['zoomlimit'] = 4;
		else newData['zoomlimit'] = zoomlimit;

		if ($('#setting-mapfill').is(':checked')) newData['mapfill'] = 'true';
		else newData['mapfill'] = false;

		if ($('#setting-zoom').is(':checked')) newData['zoom'] = 'true';
		else newData['zoom'] = false;

		if ($('#setting-alphabetic').is(':checked')) newData['alphabetic'] = 'true';
		else newData['alphabetic'] = false;

		newData['categories'] = getCategories();
		newData['levels'] = getLevels();

		$('#input-data').val(JSON.stringify(newData));
	});

	$('#mapplic-form').submit(function(event) {
		if (invalid) {
			alert(errormsg);
			event.preventDefault();
		}
	});

	var getCategories = function() {
		var categories = [];
		$('#category-list .list-item:not(.new-item)').each(function() {
			var category = {};
			
			category['id']       = $('.id-input', this).val();
			category['title']    = $('.title-input', this).val();
			category['color']    = $('.color-input', this).val();
			if (!$('.expand-input', this).is(':checked')) {
				category['show'] = 'false';
			}

			// Validation
			if (category['id'] == '') {
				if (!invalid) errormsg = 'The category titled "' + category['title'] + '" has no ID.';
				invalid = true;
			}

			categories.push(category);
		});

		return categories;
	}

	var getLevels = function() {
		var levels = [];
		$('#floor-list .list-item:not(.new-item)').each(function() {
			var level = {};

			level['id']        = $('.id-input', this).val();
			level['title']     = $('.title-input', this).val();
			level['map']       = $('.map-input', this).val();
			level['minimap']   = $('.minimap-input', this).val();
			if ($('.show-input', this).is(':checked')) {
				level['show']  = 'true';
			}
			level['locations'] = getLocations(level['id']);

			// Validation
			if (level['id'] == '') {
				if (!invalid) errormsg = 'The floor titled "' + level['title'] + '" has no ID.';
				invalid = true;
			}

			levels.push(level);
		});

		levels.reverse();

		return levels;
	}

	var getLocations = function(id) {
		var locations = [];
		
		if (typeof mapData.levels !== 'undefined') {
			$.each(mapData.levels, function(index, value) {
				if (value.id == id) {
					$.each(value.locations, function(index, value) {
						if (value.id !== null) {
							locations.push(value);
						}
					});
				}
			});
		}
		
		return locations;
	}
});